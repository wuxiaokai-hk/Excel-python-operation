@echo off
REM Double-click to start the watcher. Keep this window open; close it (or Ctrl+C) to stop.
cd /d "%~dp0"
python -m xlwatch run watch_config.json
pause
