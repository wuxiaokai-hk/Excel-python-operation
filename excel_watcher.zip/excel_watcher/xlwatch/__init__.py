"""xlwatch - watch a folder for new Excel files and copy their values with xlcopy.

Standard library only. See README.md.
"""

from .watcher import Watcher, Config

__version__ = "1.0.0"
__all__ = ["Watcher", "Config"]
