"""python -m xlwatch <command> CONFIG

  run      keep running; check every N minutes inside the time window, every day
  once     check the folder one time now (ignores the window) and exit
  test     like once, but only shows what would be copied (writes nothing)
  status   list the files already handled
  forget   forget a file (or all files) so it is processed again
"""

import argparse
import os
import sys

if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    __package__ = "xlwatch"

from .watcher import Watcher  # noqa: E402


def main(argv=None):
    p = argparse.ArgumentParser(prog="python -m xlwatch",
                                description="Watch a folder for new Excel files and copy values.")
    sub = p.add_subparsers(dest="cmd")
    a = sub.add_parser("run", help="keep running and check inside the time window")
    a.add_argument("config")
    a.add_argument("--ignore-window", action="store_true",
                   help="check every interval at any time of day (for testing)")
    a.add_argument("--exit-after-window", action="store_true",
                   help="stop when the window ends (use with Windows Task Scheduler)")
    for name, hlp in (("once", "check one time now and exit"),
                      ("test", "dry run: show what would be copied, write nothing"),
                      ("status", "show handled files")):
        a = sub.add_parser(name, help=hlp)
        a.add_argument("config")
    a = sub.add_parser("forget", help="forget handled files so they are processed again")
    a.add_argument("config")
    a.add_argument("file", nargs="?", help="file name to forget (default: all)")

    args = p.parse_args(argv)
    if not args.cmd:
        p.print_help()
        return 1
    try:
        w = Watcher(args.config)
    except (ValueError, OSError, KeyError) as e:
        print("CONFIG ERROR: %s" % e, file=sys.stderr)
        return 2

    if args.cmd == "run":
        w.run(ignore_window=args.ignore_window, exit_after_window=args.exit_after_window)
    elif args.cmd == "once":
        n = w.check_once()
        print("%d file(s) processed" % n)
    elif args.cmd == "test":
        w.state.data["initialised"] = True     # don't mark existing files during a test
        new = w.new_files()
        if not new:
            print("No new files in %s" % w.cfg.folder)
        for full, mtime, size in new:
            w.process(full, mtime, size, dry_run=True)
    elif args.cmd == "status":
        files = w.state.data.get("files", {})
        if not files:
            print("Nothing handled yet.")
        for k, v in sorted(files.items(), key=lambda kv: kv[1].get("when", "")):
            print("%-8s %-20s %s%s" % (v.get("status"), v.get("when", ""), k,
                                       ("   (" + v["error"] + ")") if v.get("error") else ""))
    elif args.cmd == "forget":
        files = w.state.data.get("files", {})
        if args.file:
            keys = [k for k in files if os.path.basename(k).lower() == os.path.basename(args.file).lower()]
            for k in keys:
                del files[k]
            print("forgot %d file(s)" % len(keys))
        else:
            files.clear()
            print("forgot all files (existing files will be treated as new)")
        w.state.data["initialised"] = True
        w.state.save()
    return 0


if __name__ == "__main__":
    sys.exit(main())
