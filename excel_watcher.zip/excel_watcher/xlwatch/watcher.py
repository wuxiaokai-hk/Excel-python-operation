"""Watch a folder for new Excel files and run xlcopy jobs on them.

Standard library only. Typical config (watch_config.json):

{
  "watch_folder": "C:/Data/Incoming",
  "patterns": ["*.xlsx", "*.xlsm"],
  "window": {"start": "08:00", "end": "09:00", "days": "Mon-Fri"},
  "interval_minutes": 2,
  "jobs": [ { "source": "{file}", ... xlcopy job settings ... } ]
}
"""

import datetime
import fnmatch
import json
import os
import shutil
import sys
import time
import traceback
import zipfile

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from xlcopy.jobs import run_jobs  # noqa: E402

_DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


# --------------------------------------------------------------------------- #
# settings
# --------------------------------------------------------------------------- #
def _parse_time(s):
    h, m = s.strip().split(":")
    return datetime.time(int(h), int(m))


def _parse_days(spec):
    """'Mon-Fri', 'Mon,Wed,Fri', ['Mon','Tue'], 'all'  ->  set of weekday numbers."""
    if spec is None or (isinstance(spec, str) and spec.strip().lower() in ("all", "daily", "")):
        return set(range(7))
    parts = spec if isinstance(spec, list) else spec.split(",")
    out = set()
    for p in parts:
        p = p.strip().lower()[:7]
        if "-" in p:
            a, b = [x.strip()[:3] for x in p.split("-")]
            i, j = _DAYS.index(a), _DAYS.index(b)
            k = i
            while True:
                out.add(k)
                if k == j:
                    break
                k = (k + 1) % 7
        else:
            out.add(_DAYS.index(p[:3]))
    return out


class Config(object):
    def __init__(self, path):
        self.path = os.path.abspath(path)
        self.base = os.path.dirname(self.path)
        with open(self.path, encoding="utf-8") as f:
            c = json.load(f)
        self.raw = c
        self.folder = self._abs(c["watch_folder"])
        self.patterns = c.get("patterns", ["*.xlsx", "*.xlsm"])
        self.recursive = bool(c.get("include_subfolders", False))
        w = c.get("window") or {}
        self.start = _parse_time(w.get("start", "00:00"))
        self.end = _parse_time(w.get("end", "23:59"))
        self.days = _parse_days(w.get("days", "all"))
        self.interval = float(c.get("interval_minutes", 2)) * 60
        self.settle = float(c.get("settle_seconds", 15))
        self.include_modified = bool(c.get("include_modified", False))
        self.first_run = c.get("existing_files_on_first_run", "ignore")
        self.stop_after_first_success = bool(c.get("stop_after_first_success", False))
        self.max_attempts = int(c.get("max_attempts", 3))
        self.state_file = self._abs(c.get("state_file", "watch_state.json"))
        self.log_file = self._abs(c.get("log_file", "watch.log"))
        self.move_to = self._abs(c["move_processed_to"]) if c.get("move_processed_to") else None
        self.skip_dates = set(str(d) for d in c.get("skip_dates", []))
        a = c.get("alerts") or {}
        self.alert_popup = bool(a.get("popup", True))
        self.alert_file = self._abs(a["alert_file"]) if a.get("alert_file") else None
        self.alert_no_file = bool(a.get("no_file_by_end_of_window", True))
        self.alert_on_failure = bool(a.get("on_failure", True))
        self.jobs = c.get("jobs") or []
        if not self.jobs:
            raise ValueError("Config has no \"jobs\"")
        if not os.path.isdir(self.folder):
            raise ValueError("watch_folder does not exist: %s" % self.folder)

    def _abs(self, p):
        p = os.path.expanduser(p)
        return p if os.path.isabs(p) else os.path.normpath(os.path.join(self.base, p))

    def in_window(self, now):
        t = now.time().replace(second=0, microsecond=0)   # the whole end minute counts
        return self.is_window_day(now.date()) and self.start <= t <= self.end

    def is_window_day(self, d):
        return d.weekday() in self.days and d.isoformat() not in self.skip_dates

    def next_window_start(self, now):
        for add in range(0, 8):
            d = (now + datetime.timedelta(days=add)).date()
            start = datetime.datetime.combine(d, self.start)
            end = datetime.datetime.combine(d, self.end)
            if self.is_window_day(d) and now <= end:
                return max(start, now)
        return None


# --------------------------------------------------------------------------- #
# state (which files were already handled) - a small JSON file
# --------------------------------------------------------------------------- #
class State(object):
    def __init__(self, path):
        self.path = path
        self.data = {"files": {}, "initialised": False}
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    self.data = json.load(f)
            except ValueError:
                pass
        self.data.setdefault("files", {})

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=1, sort_keys=True)
        os.replace(tmp, self.path)

    def get(self, key):
        return self.data["files"].get(key)

    def put(self, key, **info):
        self.data["files"][key] = info


# --------------------------------------------------------------------------- #
# the watcher
# --------------------------------------------------------------------------- #
class Watcher(object):
    def __init__(self, config_path, echo=True):
        self.cfg = Config(config_path)
        self.state = State(self.cfg.state_file)
        self.echo = echo

    # ---- logging ---------------------------------------------------------- #
    def log(self, msg):
        line = "%s  %s" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
        if self.echo:
            print(line)
            sys.stdout.flush()
        try:
            with open(self.cfg.log_file, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass

    def alert(self, msg):
        """Log, write to the alert file, and pop up a message box (Windows)."""
        self.log("ALERT: " + msg)
        if self.cfg.alert_file:
            try:
                with open(self.cfg.alert_file, "a", encoding="utf-8") as f:
                    f.write("%s  %s\n" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
            except OSError:
                pass
        if self.cfg.alert_popup and sys.platform.startswith("win"):
            import threading

            def box():
                try:
                    import ctypes
                    # MB_ICONWARNING | MB_SYSTEMMODAL | MB_SETFOREGROUND
                    ctypes.windll.user32.MessageBoxW(None, msg, "Excel watcher", 0x30 | 0x1000 | 0x10000)
                except Exception:
                    pass
            threading.Thread(target=box, daemon=True).start()

    def files_done_on(self, day):
        iso = day.isoformat()
        return [k for k, v in self.state.data.get("files", {}).items()
                if v.get("status") == "done" and str(v.get("when", "")).startswith(iso)]

    def end_of_window(self, day):
        """Called once when a window closes: alert if no file was processed that day."""
        if self.state.data.get("last_window_closed") == day.isoformat():
            return
        self.state.data["last_window_closed"] = day.isoformat()
        self.state.save()
        if self.cfg.alert_no_file and not self.files_done_on(day):
            self.alert("No new file was processed on %s between %s and %s in %s." % (
                day.isoformat(), self.cfg.start.strftime("%H:%M"), self.cfg.end.strftime("%H:%M"),
                self.cfg.folder))

    # ---- finding files ---------------------------------------------------- #
    def _candidates(self):
        out = []
        if self.cfg.recursive:
            walker = os.walk(self.cfg.folder)
        else:
            walker = [(self.cfg.folder, [], os.listdir(self.cfg.folder))]
        for root, _dirs, files in walker:
            if self.cfg.move_to and os.path.abspath(root).startswith(self.cfg.move_to):
                continue
            for name in files:
                if name.startswith("~$") or name.startswith("."):
                    continue      # Excel lock files / hidden files
                if not any(fnmatch.fnmatch(name.lower(), p.lower()) for p in self.cfg.patterns):
                    continue
                full = os.path.join(root, name)
                try:
                    st = os.stat(full)
                except OSError:
                    continue
                out.append((full, st.st_mtime, st.st_size))
        return out

    def _key(self, path):
        return os.path.relpath(path, self.cfg.folder).replace("\\", "/")

    def new_files(self):
        """Files that are new (or changed, if include_modified) and not yet done."""
        out = []
        for full, mtime, size in self._candidates():
            rec = self.state.get(self._key(full))
            if rec is None:
                out.append((full, mtime, size))
            elif rec.get("status") == "failed":
                if rec.get("attempts", 0) < self.cfg.max_attempts or \
                        (self.cfg.include_modified and abs(rec.get("mtime", 0) - mtime) > 1):
                    out.append((full, mtime, size))
            elif self.cfg.include_modified and abs(rec.get("mtime", 0) - mtime) > 1:
                out.append((full, mtime, size))
        out.sort(key=lambda x: x[1])      # oldest first
        return out

    def _is_ready(self, path, mtime, size):
        """True when the file has stopped changing and is a readable workbook."""
        # wait up to settle_seconds (capped, so a server clock ahead of ours can't stall us)
        age = time.time() - mtime
        if age < self.cfg.settle:
            time.sleep(min(self.cfg.settle, max(0.0, self.cfg.settle - age)))
        try:
            st = os.stat(path)
        except OSError:
            return False
        if st.st_size != size or abs(st.st_mtime - mtime) > 0.001:
            return False                       # still being written; try next round
        try:
            with open(path, "rb"):
                pass
            if path.lower().endswith((".xlsx", ".xlsm")) and not zipfile.is_zipfile(path):
                return False
        except OSError:
            return False
        return True

    # ---- processing ------------------------------------------------------- #
    def _jobs_for(self, path):
        name = os.path.basename(path)
        stem = os.path.splitext(name)[0]
        now = datetime.datetime.now()
        subs = {"{file}": path, "{name}": name, "{stem}": stem,
                "{date}": now.strftime("%Y-%m-%d"), "{time}": now.strftime("%H%M%S"),
                "{folder}": os.path.dirname(path)}

        def fill(v):
            if isinstance(v, str):
                for k, s in subs.items():
                    v = v.replace(k, s)
                return v
            if isinstance(v, list):
                return [fill(x) for x in v]
            if isinstance(v, dict):
                return {k: fill(x) for k, x in v.items()}
            return v

        jobs = []
        for job in self.cfg.jobs:
            pat = job.get("file_pattern")
            if pat and not fnmatch.fnmatch(name.lower(), pat.lower()):
                continue
            j = {k: fill(v) for k, v in job.items() if k != "file_pattern"}
            j.setdefault("source", path)
            jobs.append(j)
        return jobs

    def process(self, path, mtime, size, dry_run=False):
        key = self._key(path)
        jobs = self._jobs_for(path)
        if not jobs:
            self.log("SKIP %s (no job matches this file name)" % key)
            self.state.put(key, mtime=mtime, size=size, status="skipped",
                           when=datetime.datetime.now().isoformat(timespec="seconds"))
            self.state.save()
            return None
        self.log("NEW FILE %s -> running %d job(s)" % (key, len(jobs)))
        prev = self.state.get(key) or {}
        attempts = prev.get("attempts", 0) + 1 if prev.get("status") == "failed" else 1
        try:
            run_jobs(jobs, self.cfg.base, dry_run=dry_run, log=lambda m: self.log("    " + m))
        except Exception as e:  # noqa: BLE001 - we log and keep watching
            if isinstance(e, KeyError) and e.args:
                e = Exception(e.args[0])
            self.log("ERROR processing %s (attempt %d/%d): %s" % (key, attempts, self.cfg.max_attempts, e))
            self.log("    " + traceback.format_exc().strip().splitlines()[-1])
            if not dry_run and self.cfg.alert_on_failure and (attempts == 1 or attempts >= self.cfg.max_attempts):
                tail = (" Giving up on this file after %d attempts." % attempts
                        if attempts >= self.cfg.max_attempts else " Will retry at the next check.")
                self.alert("Could not process %s: %s.%s" % (key, e, tail))
            if not dry_run:
                self.state.put(key, mtime=mtime, size=size, status="failed", attempts=attempts,
                               error=str(e), when=datetime.datetime.now().isoformat(timespec="seconds"))
                self.state.save()
            return False
        if dry_run:
            return True
        self.state.put(key, mtime=mtime, size=size, status="done",
                       when=datetime.datetime.now().isoformat(timespec="seconds"))
        self.state.save()
        if self.cfg.move_to:
            os.makedirs(self.cfg.move_to, exist_ok=True)
            dst = os.path.join(self.cfg.move_to, os.path.basename(path))
            if os.path.exists(dst):
                stem, ext = os.path.splitext(dst)
                dst = "%s_%s%s" % (stem, datetime.datetime.now().strftime("%Y%m%d_%H%M%S"), ext)
            try:
                shutil.move(path, dst)
                self.log("    moved to %s" % dst)
            except OSError as e:
                self.log("    could not move file: %s" % e)
        self.log("DONE %s" % key)
        return True

    def check_once(self, dry_run=False):
        """One look at the folder. Returns number of files processed successfully."""
        if not self.state.data.get("initialised"):
            if self.cfg.first_run == "ignore":
                n = 0
                for full, mtime, size in self._candidates():
                    self.state.put(self._key(full), mtime=mtime, size=size, status="existing")
                    n += 1
                self.log("First run: %d file(s) already in the folder were marked as seen "
                         "(set \"existing_files_on_first_run\": \"process\" to handle them)." % n)
            self.state.data["initialised"] = True
            self.state.save()
        ok = 0
        for full, mtime, size in self.new_files():
            if not self._is_ready(full, mtime, size):
                self.log("WAIT %s is still being written; will check again" % self._key(full))
                continue
            st = os.stat(full)
            if self.process(full, st.st_mtime, st.st_size, dry_run=dry_run):
                ok += 1
        return ok

    # ---- loops ------------------------------------------------------------ #
    def run(self, ignore_window=False, exit_after_window=False):
        cfg = self.cfg
        self.log("Watching %s for %s every %g min, %s-%s on %s" % (
            cfg.folder, ", ".join(cfg.patterns), cfg.interval / 60,
            cfg.start.strftime("%H:%M"), cfg.end.strftime("%H:%M"),
            ",".join(_DAYS[d].title() for d in sorted(cfg.days))))
        self.log("Press Ctrl+C to stop.")
        done_today = None
        was_in_window = None
        try:
            while True:
                now = datetime.datetime.now()
                inside = cfg.in_window(now)
                if inside:
                    was_in_window = now.date()
                elif was_in_window is not None and not ignore_window:
                    self.end_of_window(was_in_window)
                    was_in_window = None
                if ignore_window or inside:
                    if not (cfg.stop_after_first_success and done_today == now.date()):
                        n = self.check_once()
                        if n and cfg.stop_after_first_success:
                            done_today = now.date()
                            self.log("Got today's file - no more checks until the next window.")
                    # sleep until the next tick (aligned to start of window)
                    time.sleep(max(1.0, cfg.interval - (time.time() % cfg.interval)
                                   if ignore_window else self._secs_to_next_tick(now)))
                    continue
                if exit_after_window:
                    self.log("Outside the time window - exiting.")
                    return
                nxt = cfg.next_window_start(now + datetime.timedelta(seconds=1))
                if nxt is None:
                    self.log("No time window on any day - check \"window\" in the config.")
                    return
                self.log("Next check window starts %s" % nxt.strftime("%a %Y-%m-%d %H:%M"))
                # sleep in chunks so the computer going to sleep does not confuse us
                while datetime.datetime.now() < nxt:
                    time.sleep(min(60, max(1, (nxt - datetime.datetime.now()).total_seconds())))
        except KeyboardInterrupt:
            self.log("Stopped by user.")

    def _secs_to_next_tick(self, now):
        start = datetime.datetime.combine(now.date(), self.cfg.start)
        elapsed = (now - start).total_seconds()
        k = int(elapsed // self.cfg.interval) + 1
        nxt = start + datetime.timedelta(seconds=k * self.cfg.interval)
        end = datetime.datetime.combine(now.date(), self.cfg.end)
        if nxt > end:
            # leave the window: wake just after it ends so the main loop reschedules
            return max(1.0, (end - now).total_seconds() + 1)
        return max(1.0, (nxt - now).total_seconds())
