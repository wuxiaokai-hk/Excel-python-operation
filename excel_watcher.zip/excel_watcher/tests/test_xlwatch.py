"""Self-tests. Run from the project folder:  python -m unittest discover tests"""

import datetime
import json
import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from xlcopy import Workbook  # noqa: E402
from xlwatch.watcher import Watcher, _parse_days  # noqa: E402


def make_source(path, month, gdp):
    wb = Workbook.new(["Data"])
    wb.write_rows("Data", "A1", [["Date", "Region", "GDP"],
                                 [datetime.datetime(2026, month, 1), "ON", gdp],
                                 [datetime.datetime(2026, month, 1), "BC", gdp + 1]])
    wb.save(path)


class WatchTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.d, "in"))
        t = Workbook.new(["Input"])
        t.write_rows("Input", "A1", [["Date", "GDP"]])
        t.save(os.path.join(self.d, "model.xlsx"))
        make_source(os.path.join(self.d, "in", "old.xlsx"), 1, 10)
        self.cfg = os.path.join(self.d, "cfg.json")
        with open(self.cfg, "w") as f:
            json.dump({"watch_folder": "in", "settle_seconds": 0,
                       "window": {"start": "08:00", "end": "09:00", "days": "Mon-Fri"},
                       "jobs": [{"source": "{file}", "where": {"Region": "ON"},
                                 "columns": ["Date", "GDP"], "target": "model.xlsx",
                                 "target_sheet": "Input", "mode": "match_headers", "key": "Date"}]}, f)

    def tearDown(self):
        shutil.rmtree(self.d)

    def rows(self):
        return Workbook.open(os.path.join(self.d, "model.xlsx")).read_rows("Input")

    def test_flow(self):
        w = Watcher(self.cfg, echo=False)
        self.assertEqual(w.check_once(), 0)                     # old file ignored on first run
        make_source(os.path.join(self.d, "in", "new.xlsx"), 2, 20)
        with open(os.path.join(self.d, "in", "~$new.xlsx"), "w") as f:
            f.write("lock")
        self.assertEqual(w.check_once(), 1)
        self.assertEqual(self.rows()[1], [datetime.datetime(2026, 2, 1), 20])
        self.assertEqual(Watcher(self.cfg, echo=False).check_once(), 0)   # remembered after restart

    def test_retry_after_failure(self):
        w = Watcher(self.cfg, echo=False)
        w.check_once()
        model = os.path.join(self.d, "model.xlsx")
        shutil.move(model, model + ".keep")
        with open(model, "w") as f:
            f.write("broken")
        make_source(os.path.join(self.d, "in", "new.xlsx"), 3, 30)
        self.assertEqual(w.check_once(), 0)
        self.assertEqual(w.state.get("new.xlsx")["status"], "failed")
        shutil.move(model + ".keep", model)
        self.assertEqual(w.check_once(), 1)
        self.assertEqual(w.state.get("new.xlsx")["status"], "done")

    def test_alerts(self):
        with open(self.cfg) as f:
            c = json.load(f)
        c["alerts"] = {"popup": False, "alert_file": "alerts.txt"}
        c["skip_dates"] = ["2026-12-25"]
        with open(self.cfg, "w") as f:
            json.dump(c, f)
        w = Watcher(self.cfg, echo=False)
        w.check_once()
        w.end_of_window(datetime.date(2026, 11, 12))
        w.end_of_window(datetime.date(2026, 11, 12))     # only once per day
        with open(os.path.join(self.d, "alerts.txt")) as f:
            self.assertEqual(f.read().count("No new file"), 1)
        self.assertFalse(w.cfg.in_window(datetime.datetime(2026, 12, 25, 8, 30)))

    def test_window(self):
        c = Watcher(self.cfg, echo=False).cfg
        N = datetime.datetime
        self.assertTrue(c.in_window(N(2026, 11, 12, 8, 30)))       # Thursday
        self.assertTrue(c.in_window(N(2026, 11, 12, 9, 0, 30)))    # end minute counts
        self.assertFalse(c.in_window(N(2026, 11, 12, 9, 1)))
        self.assertFalse(c.in_window(N(2026, 11, 14, 8, 30)))      # Saturday
        self.assertEqual(c.next_window_start(N(2026, 11, 13, 10, 0)), N(2026, 11, 16, 8, 0))
        self.assertEqual(_parse_days("Fri-Mon"), {4, 5, 6, 0})


if __name__ == "__main__":
    unittest.main()
