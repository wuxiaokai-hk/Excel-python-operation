# excel_watcher

This tool watches a folder for new Excel files during a time window you set, for example every 2 minutes between 8:00 and 9:00 on weekdays. When a new file arrives, it reads the values you choose and writes them into another workbook.

It uses only the Python standard library, so there's no `pip install`. It relies on the bundled `xlcopy` package for reading and writing Excel.

```
excel_watcher/
├── xlwatch/            the watcher
├── xlcopy/             Excel read/filter/write (bundled copy)
├── watch_config.json   your settings (edit this)
├── run_watch.bat       double-click to start (Windows)
└── tests/
```

## Quick start

1. Edit `watch_config.json`:
   - `watch_folder`: the folder where the new files arrive
   - `jobs`: what to copy and where it goes (see below)
2. Do a dry run. It shows what would be copied and writes nothing:
   ```
   python -m xlwatch test watch_config.json
   ```
3. Start the watcher. Either double-click `run_watch.bat`, or run:
   ```
   python -m xlwatch run watch_config.json
   ```
   Leave the window open. Outside the time window the watcher sleeps; inside it, the watcher checks every `interval_minutes`. Press Ctrl+C or close the window to stop.

## How it decides a file is "new"

- **First run:** the watcher records the files already in the folder and doesn't process them. Set `"existing_files_on_first_run": "process"` if you want them handled.
- **New file:** any file matching `patterns` that the watcher hasn't seen before. Excel's temporary `~$...` lock files are ignored.
- **Partly copied files:** a file is processed only after its size has stayed the same for `settle_seconds` and it opens as a valid workbook. A file still being copied is picked up on the next check.
- **Status tracking:** every processed file is recorded in `watch_state.json`, so a file is never processed twice, even if you restart the watcher.
- **Failures:** if a job fails (for example, the target workbook is open in Excel), the file is marked `failed` and retried at the next check, up to `max_attempts` times. Nothing is saved for a failed run.
- **Changed files:** with `"include_modified": true`, a file that changes after it was processed is treated as new again.

Everything that happens is written to `watch.log`.

## Settings

| setting | meaning |
|---|---|
| `watch_folder` | folder to watch (absolute, or relative to the config file) |
| `patterns` | which files count, e.g. `["*.xlsx"]` or `["Daily_*.xlsx"]` |
| `include_subfolders` | `true` to also watch subfolders |
| `window` | `{"start": "08:00", "end": "09:00", "days": "Mon-Fri"}`. `days` can also be `"all"`, `"Mon,Wed,Fri"` or a list. The whole end minute counts. |
| `interval_minutes` | how often to check inside the window (decimals are allowed) |
| `settle_seconds` | how long a file must stay unchanged before it's read |
| `stop_after_first_success` | `true` to stop checking for the rest of the day once one file is processed |
| `move_processed_to` | optional folder to move a processed file into; omit it to leave files where they are |
| `max_attempts` | number of retries for a file that failed |
| `state_file`, `log_file` | where the watcher keeps its memory and its log |
| `skip_dates` | dates with no checks and no alerts, e.g. holidays: `["2026-12-25", "2027-01-01"]` |
| `alerts` | `{"popup": true, "alert_file": "ALERTS.txt", "no_file_by_end_of_window": true, "on_failure": true}` |
| `jobs` | the copy steps (below) |

### Jobs

Jobs use the same settings as `xlcopy` jobs; the `xlcopy` README lists all of them. Use `{file}` as the source and it's replaced by the new file's path:

```json
{
  "name": "Daily inputs into model",
  "source": "{file}",
  "source_sheet": "Data",
  "where": {"Region": "ON"},
  "columns": ["Date", "GDP", "CPI"],
  "target": "C:/Models/model.xlsx",
  "target_sheet": "Input",
  "mode": "match_headers",
  "key": "Date"
}
```

You can use these placeholders in any text setting:

- `{file}`: full path of the new file
- `{name}`: its file name
- `{stem}`: its name without the extension
- `{folder}`: the folder it's in
- `{date}` and `{time}`: when it was processed

For example, `"output": "archive/{stem}_copy.xlsx"`.

Add `"refresh": "excel"` to a job to have Excel run Refresh All and recalculate the target after the values are written. This needs Windows with Excel installed; `"on_open"` instead makes Excel refresh when the file is next opened.

Add `"file_pattern": "GDP_*.xlsx"` to a job to run it only for files whose names match. This lets different files trigger different jobs.

To change values in place instead of pasting a block, use `"mode": "match_headers"` with a `key`. Rows are matched on the key (e.g. Date), each column is written under its matching header, and keys not yet in the target are added at the bottom.

### Checks, clean numbers and change reports

Every job can use the newer `xlcopy` options:

- **`"to_numbers": ["GDP", "CPI"]`** converts numbers stored as text, such as `"1,234"` or `"2.1%"`.
- **`"checks": {...}`** validates the data before anything is written. It covers required columns, minimum rows, no blanks, numeric columns, unique dates, value ranges, and the largest allowed jump. A failed check stops the job, leaves the target untouched, and raises an alert.
- **`"compare": true`** writes `model_changes_<date_time>.xlsx` next to the target after each run. It lists every cell that changed, with the old and new value.
- **`"backup": true`** keeps `model.xlsx.bak`.

The `xlcopy` README describes each option.

### Alerts

An alert is written to the log, appended to `alert_file`, and shown as a pop-up window on Windows. You get one:

- when a window ends without any file having been processed that day (holidays listed in `skip_dates` are skipped)
- when a file fails, on the first attempt and when the watcher gives up on it.

Set `"popup": false` to get only the file and the log.

## Commands

```
python -m xlwatch run    watch_config.json                    # keep running, every day
python -m xlwatch run    watch_config.json --ignore-window    # check all day (for testing)
python -m xlwatch run    watch_config.json --exit-after-window
python -m xlwatch once   watch_config.json                    # one check now, then exit
python -m xlwatch test   watch_config.json                    # dry run, writes nothing
python -m xlwatch status watch_config.json                    # list handled files
python -m xlwatch forget watch_config.json daily.xlsx         # process that file again
python -m xlwatch forget watch_config.json                    # forget everything
```

## Running it automatically

- **Option A: leave it running.** Start `run_watch.bat` in the morning, or once and leave it. It sleeps until 8:00 each weekday. The computer must be on and not asleep during the window.
- **Option B: Windows Task Scheduler**, if your account is allowed to create tasks. Create a task that starts at 07:59 on weekdays and runs `python -m xlwatch run watch_config.json --exit-after-window`, with **Start in** set to this folder. It checks until 9:00 and then exits by itself.

## Good to know

- Close the target workbook in Excel during the window. If it's open, the save fails, the error goes to the log, and the file is retried at the next check.
- Formulas in the target that depend on the pasted cells recalculate when you next open it in Excel.
- Run the self-tests from this folder with `python -m unittest discover tests`.
