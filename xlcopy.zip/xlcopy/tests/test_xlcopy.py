"""Self-tests. Run from the project folder:  python -m unittest discover tests"""

import datetime
import os
import shutil
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import xlcopy  # noqa: E402
from xlcopy import Workbook, Formula, Table, XlcopyError  # noqa: E402


class XlcopyTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.src = os.path.join(self.d, "src.xlsx")
        wb = Workbook.new(["Data", "Notes"])
        rows = [["Date", "Region", "GDP", "CPI", "Note"]]
        for m in range(1, 13):
            for reg in ("ON", "BC"):
                rows.append([datetime.datetime(2024, m, 1), reg, m * 1.5, 100 + m, "a & <b>" if m == 1 else None])
        wb.write_rows("Data", "A1", rows)
        wb.set("Notes", "A1", "keep me")
        wb.save(self.src)
        self.tpl = os.path.join(self.d, "tpl.xlsx")
        t = Workbook.new(["Input"])
        t.write_rows("Input", "A1", [["Date", "GDP", "CPI", "Total"]])
        for r in range(2, 30):
            t.set("Input", "D%d" % r, Formula("B%d+C%d" % (r, r)))
        t.save(self.tpl)

    def tearDown(self):
        shutil.rmtree(self.d)

    def test_read(self):
        t = xlcopy.read_table(self.src, "Data")
        self.assertEqual(t.columns, ["Date", "Region", "GDP", "CPI", "Note"])
        self.assertEqual(len(t), 24)
        self.assertEqual(t.rows[0][0], datetime.datetime(2024, 1, 1))
        self.assertEqual(t.rows[0][4], "a & <b>")
        self.assertEqual(xlcopy.sheet_names(self.src), ["Data", "Notes"])

    def test_filter(self):
        t = xlcopy.read_table(self.src, "Data")
        on = t.where("region", "on").select("Date", "gdp").between("Date", "2024-03-01", "2024-05-01")
        self.assertEqual(on.columns, ["Date", "GDP"])
        self.assertEqual(len(on), 3)
        self.assertEqual(len(t.where("Region", ["ON", "BC"])), 24)
        self.assertEqual(len(t.filter(lambda r: r["GDP"] > 15)), 4)
        with self.assertRaises(KeyError):
            t.select("GDPP")

    def test_transpose(self):
        t = Table(["Var", "2024", "2025"], [["GDP", 1, 2], ["CPI", 3, 4]]).transpose()
        self.assertEqual(t.columns, ["Var", "GDP", "CPI"])
        self.assertEqual(t.rows, [["2024", 1, 3], ["2025", 2, 4]])

    def test_paste_and_preserve(self):
        out = os.path.join(self.d, "out.xlsx")
        t = xlcopy.read_table(self.src, "Data").where("Region", "ON").select("Date", "GDP", "CPI")
        xlcopy.write_table(self.tpl, t, sheet="Input", start="A1", out=out)
        wb = Workbook.open(out)
        self.assertEqual(wb.get("Input", "B3"), 3)
        self.assertEqual(wb.get("Input", "A2"), datetime.datetime(2024, 1, 1))
        raw = zipfile.ZipFile(out).read("xl/worksheets/sheet1.xml").decode()
        self.assertIn("<f>B2+C2</f>", raw)

    def test_by_header_with_key(self):
        out = os.path.join(self.d, "out.xlsx")
        t = xlcopy.read_table(self.src, "Data").where("Region", "ON").select("Date", "CPI")
        xlcopy.write_table(self.tpl, t.head(3), sheet="Input", by_header=True, key="Date", out=out)
        t2 = xlcopy.read_table(self.src, "Data").where("Region", "ON").select("Date", "GDP")
        rep = xlcopy.write_table(out, t2.head(4), sheet="Input", by_header=True, key="Date")
        self.assertEqual(rep["rows_added"], 1)
        rows = xlcopy.read_rows(out, "Input", "A1:C5")
        self.assertEqual(rows[1], [datetime.datetime(2024, 1, 1), 1.5, 101])
        self.assertEqual(rows[4], [datetime.datetime(2024, 4, 1), 6, None])

    def test_clear_and_new_sheet(self):
        out = os.path.join(self.d, "out.xlsx")
        wb = Workbook.open(self.src)
        wb.clear("Data", "C2:D100")
        wb.add_sheet("Copy")
        wb.write_rows("Copy", "B2", [[1, "x"], [True, None]])
        wb.save(out)
        wb = Workbook.open(out)
        self.assertIsNone(wb.get("Data", "C2"))
        self.assertEqual(wb.get("Data", "B2"), "ON")
        self.assertEqual(wb.read_rows("Copy", "B2:C3"), [[1, "x"], [True, None]])
        self.assertEqual(wb.sheet_names, ["Data", "Notes", "Copy"])

    def test_errors(self):
        with self.assertRaises(XlcopyError):
            Workbook.open(self.src).sheet("Nope")
        bad = os.path.join(self.d, "bad.xlsx")
        with open(bad, "w") as f:
            f.write("a,b\n")
        with self.assertRaises(XlcopyError):
            Workbook.open(bad)

    def test_jobs(self):
        cfg = os.path.join(self.d, "job.json")
        with open(cfg, "w") as f:
            f.write('{"jobs": [{"source": "src.xlsx", "source_sheet": "Data", '
                    '"columns": ["Date", "GDP"], "where": {"Region": "BC"}, '
                    '"target": "tpl.xlsx", "target_sheet": "Input", "mode": "match_headers", '
                    '"output": "filled.xlsx"}]}')
        xlcopy.run_jobs(cfg)
        self.assertEqual(xlcopy.read_rows(os.path.join(self.d, "filled.xlsx"), "Input", "B2:B3"), [[1.5], [3]])

    def test_refresh_on_open(self):
        out = os.path.join(self.d, "r.xlsx")
        msg = xlcopy.refresh(self.tpl, out=out, method="on_open")
        self.assertIn("formulas", msg)
        wbxml = zipfile.ZipFile(out).read("xl/workbook.xml").decode()
        self.assertIn('fullCalcOnLoad="1"', wbxml)
        self.assertEqual(xlcopy.read_rows(out, "Input", "A1:B1"), [["Date", "GDP"]])
        if not sys.platform.startswith("win"):
            with self.assertRaises(XlcopyError):
                xlcopy.refresh(self.tpl, method="excel")
            self.assertIn("on open", xlcopy.refresh(self.tpl, out=out))   # auto falls back

    def test_compare(self):
        out = os.path.join(self.d, "changed.xlsx")
        wb = Workbook.open(self.src)
        wb.set("Data", "C2", 99)              # changed
        wb.set("Data", "E4", "new note")      # added
        wb.set("Data", "B4", None)            # deleted
        wb.set("Data", "F2", Formula("C2*2"))  # formula added
        wb.save(out)
        rep = os.path.join(self.d, "rep.xlsx")
        ch = xlcopy.compare(self.src, out, report=rep)
        kinds = {c.cell: c.kind for c in ch}
        self.assertEqual(kinds, {"C2": "changed", "E4": "added", "B4": "deleted", "F2": "formula added"})
        c2 = [c for c in ch if c.cell == "C2"][0]
        self.assertEqual((c2.old, c2.new, c2.diff, c2.col_header), (1.5, 99, 97.5, "GDP"))
        self.assertEqual(xlcopy.read_rows(rep, "Changes")[0][0], "Sheet")
        self.assertEqual(xlcopy.compare(self.src, self.src), [])

    def test_to_numbers_and_checks(self):
        t = Table(["Date", "GDP", "CPI"], [["2024-01-01", "1,234.5", "2.5%"], ["2024-02-01", "(3)", "n/a"]])
        n = t.to_numbers("GDP", "CPI")
        self.assertEqual(n.column("GDP"), [1234.5, -3])
        self.assertEqual(n.column("CPI"), [0.025, "n/a"])
        probs = xlcopy.run_checks(n, {"numeric": ["CPI"], "min_rows": 3, "unique": ["Date"],
                                      "ranges": {"GDP": [0, None]}, "required_columns": ["UR"]})
        self.assertEqual(len(probs), 4)
        self.assertEqual(xlcopy.run_checks(n, {"numeric": ["GDP"], "unique": ["Date"]}), [])


if __name__ == "__main__":
    unittest.main()
