"""Example: build two sample workbooks, then filter and copy between them.

Run from anywhere:  python examples/example_script.py
"""

import datetime
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))   # folder that contains xlcopy/

import xlcopy                                 # noqa: E402
from xlcopy import Workbook, Formula          # noqa: E402

src = os.path.join(HERE, "sample_source.xlsx")
tpl = os.path.join(HERE, "sample_template.xlsx")

# --- make sample files (you would already have these) ---------------------- #
wb = Workbook.new(["Data"])
rows = [["Date", "Region", "GDP", "CPI", "Unemployment"]]
for i in range(24):
    d = datetime.datetime(2024 + i // 12, i % 12 + 1, 1)
    for k, reg in enumerate(["ON", "BC", "QC"]):
        rows.append([d, reg, 100 + i + k * 10, 150 + i * 0.4, 5.5 + 0.05 * i])
wb.write_rows("Data", "A1", rows)
wb.save(src)

t = Workbook.new(["Input"])
t.write_rows("Input", "A1", [["Date", "GDP", "CPI", "UR", "Real GDP index"]])
for r in range(2, 26):
    t.set("Input", "E%d" % r, Formula("IF(B%d=\"\",\"\",B%d/C%d*100)" % (r, r, r)))
t.save(tpl)

# --- the actual work: 4 lines ---------------------------------------------- #
data = xlcopy.read_table(src, sheet="Data")
on = data.where("Region", "ON").select("Date", "GDP", "CPI", "Unemployment", rename={"Unemployment": "UR"})
on.show(5)
report = xlcopy.write_table(tpl, on, sheet="Input", by_header=True, key="Date",
                            out=os.path.join(HERE, "sample_filled.xlsx"))
print(report)

# --- or run the same kind of thing from the JSON job file ------------------ #
xlcopy.run_jobs(os.path.join(HERE, "jobs_example.json"))
