"""Validation checks for a Table before it is written anywhere.

    problems = run_checks(table, {"required_columns": ["Date", "GDP"], "min_rows": 12})

Supported checks (all optional):
    required_columns : columns that must exist
    min_rows / max_rows : row count limits
    no_blanks        : columns that may not have empty cells
    numeric          : columns whose non-empty cells must all be numbers
    unique           : columns whose values may not repeat (e.g. Date)
    ranges           : {"GDP": [0, 5000], "UR": [0, null]} - allowed min/max
    max_change_pct   : {"GDP": 20} - largest allowed % change between consecutive rows
"""

from ._cells import norm


def _blank(v):
    return v is None or (isinstance(v, str) and v.strip() == "")


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def run_checks(table, checks):
    """Return a list of problem descriptions (empty list = all good)."""
    p = []
    if not checks:
        return p
    for col in checks.get("required_columns", []):
        if not table.has(col):
            p.append("missing column %r (columns are %s)" % (col, table.columns))
    n = len(table)
    if "min_rows" in checks and n < checks["min_rows"]:
        p.append("only %d rows; expected at least %d" % (n, checks["min_rows"]))
    if "max_rows" in checks and n > checks["max_rows"]:
        p.append("%d rows; expected at most %d" % (n, checks["max_rows"]))

    def col_values(col, what):
        if not table.has(col):
            p.append("%s: column %r not found" % (what, col))
            return None
        return table.column(col)

    for col in checks.get("no_blanks", []):
        vals = col_values(col, "no_blanks")
        if vals is not None:
            bad = [i + 1 for i, v in enumerate(vals) if _blank(v)]
            if bad:
                p.append("%r has %d empty cell(s), first at data row %d" % (col, len(bad), bad[0]))
    for col in checks.get("numeric", []):
        vals = col_values(col, "numeric")
        if vals is not None:
            bad = [(i + 1, v) for i, v in enumerate(vals) if not _blank(v) and not _is_num(v)]
            if bad:
                p.append("%r has %d non-numeric value(s), e.g. %r at data row %d"
                         % (col, len(bad), bad[0][1], bad[0][0]))
    for col in checks.get("unique", []):
        vals = col_values(col, "unique")
        if vals is not None:
            seen, dups = set(), []
            for v in vals:
                k = norm(v)
                if k in seen and k is not None:
                    dups.append(v)
                seen.add(k)
            if dups:
                p.append("%r has %d repeated value(s), e.g. %r" % (col, len(dups), dups[0]))
    for col, lim in (checks.get("ranges") or {}).items():
        vals = col_values(col, "ranges")
        if vals is None:
            continue
        lo, hi = (list(lim) + [None, None])[:2]
        bad = [v for v in vals if _is_num(v) and ((lo is not None and v < lo) or (hi is not None and v > hi))]
        if bad:
            p.append("%r has %d value(s) outside [%s, %s], e.g. %r" % (col, len(bad), lo, hi, bad[0]))
    for col, maxpct in (checks.get("max_change_pct") or {}).items():
        vals = col_values(col, "max_change_pct")
        if vals is None:
            continue
        nums = [v for v in vals if _is_num(v)]
        for i in range(1, len(nums)):
            a, b = nums[i - 1], nums[i]
            if a and abs((b - a) / abs(a)) * 100 > maxpct:
                p.append("%r jumps %.1f%% (%r -> %r); limit is %s%%" % (col, (b - a) / abs(a) * 100, a, b, maxpct))
                break
    unknown = set(checks) - {"required_columns", "min_rows", "max_rows", "no_blanks", "numeric",
                             "unique", "ranges", "max_change_pct"}
    if unknown:
        p.append("unknown check(s): %s" % sorted(unknown))
    return p
