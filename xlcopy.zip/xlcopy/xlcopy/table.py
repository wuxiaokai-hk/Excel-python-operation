"""A tiny table type for picking variables (columns) and filtering rows."""

import datetime
import difflib
import re

from ._cells import norm, parse_date_string, index_to_col


def _as_list(x):
    if x is None:
        return []
    if isinstance(x, (list, tuple, set)):
        return list(x)
    return [x]


def _comparable(v):
    """Make dates, date-strings and numbers comparable for between()."""
    if isinstance(v, datetime.datetime):
        return v
    if isinstance(v, datetime.date):
        return datetime.datetime(v.year, v.month, v.day)
    if isinstance(v, str):
        d = parse_date_string(v)
        if d is not None:
            return d
        try:
            return float(v.replace(",", ""))
        except ValueError:
            return v.strip().casefold()
    return v


_NUM_RE = re.compile(r"^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$")
_CURRENCY = "$\u20ac\u00a3\u00a5"


def text_to_number(v, percent_as_fraction=True):
    """'1,234' -> 1234, '(5.2)' -> -5.2, '3.1%' -> 0.031; anything else unchanged."""
    if not isinstance(v, str):
        return v
    s = v.strip().replace("\u00a0", "").replace(" ", "")
    if not s:
        return v
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg, s = True, s[1:-1]
    pct = s.endswith("%")
    if pct:
        s = s[:-1]
    s = s.lstrip(_CURRENCY)
    if s.startswith("-") and len(s) > 1 and s[1] in _CURRENCY:
        s = "-" + s[2:]
    s = s.replace(",", "")
    if not _NUM_RE.match(s):
        return v
    x = float(s)
    if neg:
        x = -x
    if pct and percent_as_fraction:
        import decimal
        x = float(decimal.Decimal(s) / 100) * (-1 if neg else 1)
    if x.is_integer() and "." not in s and "e" not in s.lower() and not pct:
        return int(x)
    return x


class Table(object):
    """Rows of values with named columns.

    Every method returns a NEW Table, so you can chain:
        t.select("Date", "GDP", "CPI").where("Region", ["ON", "BC"]).between("Date", "2020-01-01", None)
    """

    def __init__(self, columns, rows):
        self.columns = list(columns)
        w = len(self.columns)
        self.rows = [(list(r) + [None] * (w - len(r)))[:w] for r in rows]

    # ---- construction ----------------------------------------------------- #
    @classmethod
    def from_rows(cls, rows, header_row=1):
        """Use row number `header_row` (1-based) of `rows` as the column names."""
        if not rows:
            return cls([], [])
        header = list(rows[header_row - 1])
        data = rows[header_row:]
        # drop trailing columns that have no header and no data
        width = len(header)
        while width > 0 and (header[width - 1] is None or str(header[width - 1]).strip() == "") \
                and all(len(r) < width or r[width - 1] is None for r in data):
            width -= 1
        cols = []
        for i, h in enumerate(header[:width]):
            if h is None or str(h).strip() == "":
                h = "Unnamed_%s" % index_to_col(i + 1)
            elif isinstance(h, str):
                h = h.strip()
            cols.append(h)
        return cls(cols, [r[:width] for r in data])

    # ---- basics ----------------------------------------------------------- #
    def __len__(self):
        return len(self.rows)

    def __iter__(self):
        return iter(self.to_dicts())

    def __repr__(self):
        return "<Table %d rows x %d columns>\n%s" % (len(self.rows), len(self.columns), self.preview(5))

    def index(self, name):
        """Position of a column, matching names ignoring case/spaces."""
        key = norm(name)
        for i, c in enumerate(self.columns):
            if norm(c) == key:
                return i
        names = [str(c) for c in self.columns]
        close = difflib.get_close_matches(str(name), names, n=3, cutoff=0.5)
        hint = (" Did you mean: %s?" % ", ".join(repr(c) for c in close)) if close else ""
        raise KeyError("Column %r not found.%s Available columns: %s" % (name, hint, names))

    def has(self, name):
        try:
            self.index(name)
            return True
        except KeyError:
            return False

    def column(self, name):
        i = self.index(name)
        return [r[i] for r in self.rows]

    def to_rows(self, header=True):
        out = [list(self.columns)] if header else []
        out.extend(list(r) for r in self.rows)
        return out

    def to_dicts(self):
        return [dict(zip(self.columns, r)) for r in self.rows]

    # ---- choosing columns ------------------------------------------------- #
    def select(self, *names, **kw):
        """Keep only these columns, in this order. select('A','B') or select(['A','B']).

        rename={'old': 'new'} renames at the same time.
        missing='error' (default) or 'skip' to ignore names that are not found.
        """
        if len(names) == 1 and isinstance(names[0], (list, tuple)):
            names = names[0]
        missing = kw.get("missing", "error")
        idx = []
        for n in names:
            try:
                idx.append(self.index(n))
            except KeyError:
                if missing != "skip":
                    raise
        t = Table([self.columns[i] for i in idx], [[r[i] for i in idx] for r in self.rows])
        if kw.get("rename"):
            t = t.rename(kw["rename"])
        return t

    def select_if(self, func):
        """Keep columns whose header passes func(header), e.g. lambda h: str(h).startswith('GDP')."""
        idx = [i for i, c in enumerate(self.columns) if func(c)]
        return Table([self.columns[i] for i in idx], [[r[i] for i in idx] for r in self.rows])

    def drop(self, *names):
        if len(names) == 1 and isinstance(names[0], (list, tuple)):
            names = names[0]
        gone = {self.index(n) for n in names}
        keep = [i for i in range(len(self.columns)) if i not in gone]
        return Table([self.columns[i] for i in keep], [[r[i] for i in keep] for r in self.rows])

    def rename(self, mapping):
        new = list(self.columns)
        for old, nw in mapping.items():
            new[self.index(old)] = nw
        return Table(new, self.rows)

    # ---- choosing rows ---------------------------------------------------- #
    def where(self, column, value):
        """Keep rows where `column` matches.

        value can be a single value ('ON'), a list (['ON', 'BC']) or a
        function (lambda v: v is not None and v > 0). Text matching ignores
        case and surrounding spaces; '2025-01-01' matches a date cell.
        """
        i = self.index(column)
        if callable(value):
            keep = [r for r in self.rows if value(r[i])]
        else:
            wanted = {norm(v) for v in _as_list(value)}
            keep = [r for r in self.rows if norm(r[i]) in wanted]
        return Table(self.columns, keep)

    def where_not(self, column, value):
        i = self.index(column)
        unwanted = {norm(v) for v in _as_list(value)}
        return Table(self.columns, [r for r in self.rows if norm(r[i]) not in unwanted])

    def between(self, column, low=None, high=None):
        """Keep rows with low <= column <= high (either end may be None). Works for dates and numbers."""
        i = self.index(column)
        lo = _comparable(low) if low is not None else None
        hi = _comparable(high) if high is not None else None
        keep = []
        for r in self.rows:
            v = _comparable(r[i])
            if v is None:
                continue
            try:
                if lo is not None and v < lo:
                    continue
                if hi is not None and v > hi:
                    continue
            except TypeError:
                continue
            keep.append(r)
        return Table(self.columns, keep)

    def filter(self, func):
        """Keep rows where func(row_dict) is True, e.g. lambda r: r['GDP'] > 0."""
        return Table(self.columns, [r for r in self.rows if func(dict(zip(self.columns, r)))])

    def drop_empty_rows(self):
        return Table(self.columns, [r for r in self.rows
                                    if any(v is not None and not (isinstance(v, str) and v.strip() == "")
                                           for v in r)])

    def head(self, n=5):
        return Table(self.columns, self.rows[:n])

    # ---- reshaping -------------------------------------------------------- #
    def transpose(self, first_header=None):
        """Turn rows into columns.

        Useful when variables are in rows and dates go across (wide format).
        The first column becomes the new header row.
        """
        if not self.columns:
            return self
        new_cols = [first_header if first_header is not None else self.columns[0]]
        new_cols += [r[0] for r in self.rows]
        new_rows = []
        for j in range(1, len(self.columns)):
            new_rows.append([self.columns[j]] + [r[j] for r in self.rows])
        return Table(new_cols, new_rows)

    def map_column(self, name, func):
        """Apply func to every value of one column (e.g. convert units)."""
        i = self.index(name)
        rows = [list(r) for r in self.rows]
        for r in rows:
            r[i] = func(r[i])
        return Table(self.columns, rows)

    def to_numbers(self, *names, **kw):
        """Turn numbers stored as text into real numbers.

        Handles '1,234.5', ' 12 ', '(5.2)' (negative), '-3', '$1,000', '3.1%' (-> 0.031),
        '1.2e3'. Text that is not a number is left as it is.
        With no column names, every column is converted.
        percent_as_fraction=False keeps '3.1%' as 3.1.
        """
        if len(names) == 1 and isinstance(names[0], (list, tuple)):
            names = names[0]
        idx = [self.index(n) for n in names] if names else list(range(len(self.columns)))
        frac = kw.get("percent_as_fraction", True)
        rows = [list(r) for r in self.rows]
        for r in rows:
            for i in idx:
                r[i] = text_to_number(r[i], frac)
        return Table(self.columns, rows)

    # ---- display ---------------------------------------------------------- #
    def preview(self, n=10, width=14):
        def fmt(v):
            if v is None:
                s = ""
            elif isinstance(v, datetime.datetime) and v.hour == v.minute == v.second == 0:
                s = v.date().isoformat()
            elif isinstance(v, float):
                s = "%.6g" % v
            else:
                s = str(v)
            return (s[:width - 1] + "~") if len(s) > width else s.ljust(width)
        lines = [" | ".join(fmt(c) for c in self.columns)]
        lines.append("-+-".join("-" * width for _ in self.columns))
        for r in self.rows[:n]:
            lines.append(" | ".join(fmt(v) for v in r))
        if len(self.rows) > n:
            lines.append("... (%d more rows)" % (len(self.rows) - n))
        return "\n".join(lines)

    def show(self, n=10):
        print(self.preview(n))
