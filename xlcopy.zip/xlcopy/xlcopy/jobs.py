"""Run copy jobs described in a JSON file, so a repeated task is one command.

Example job file (paths are relative to the JSON file):

{
  "jobs": [
    {
      "name": "Macro inputs",
      "source": "data/scenario_export.xlsx",
      "source_sheet": "Data",
      "header_row": 1,
      "columns": ["Date", "GDP", "CPI", "Unemployment"],
      "rename": {"Unemployment": "UR"},
      "where": {"Scenario": "Baseline"},
      "between": {"Date": ["2020-01-01", "2030-12-31"]},
      "target": "model/template.xlsx",
      "target_sheet": "Input",
      "mode": "paste",
      "start": "A1",
      "write_header": true,
      "clear": "A2:Z5000",
      "output": "model/template_filled.xlsx"
    }
  ]
}
"""

import datetime
import json
import os

from .workbook import Workbook, XlcopyError
from .checks import run_checks

_KNOWN = {"name", "source", "source_sheet", "source_range", "header_row", "columns", "rename",
          "where", "where_not", "between", "transpose", "target", "target_sheet", "mode", "start",
          "write_header", "target_header_row", "key", "add_missing_keys", "clear", "output",
          "create_sheet", "backup", "refresh", "to_numbers", "checks", "compare", "comment", "_comment"}


def _resolve(base, p):
    if p is None:
        return None
    p = os.path.expanduser(p)
    return p if os.path.isabs(p) else os.path.normpath(os.path.join(base, p))


def build_table(job, base, cache=None):
    """Read and filter the source data of one job. Returns a Table."""
    cache = {} if cache is None else cache
    src = _resolve(base, job["source"])
    if src not in cache:
        cache[src] = Workbook.open(src)
    wb = cache[src]
    t = wb.read_table(job.get("source_sheet"), header_row=job.get("header_row", 1),
                      range=job.get("source_range"))
    if job.get("transpose"):
        t = t.transpose()
    for col, val in (job.get("where") or {}).items():
        t = t.where(col, val)
    for col, val in (job.get("where_not") or {}).items():
        t = t.where_not(col, val)
    for col, lim in (job.get("between") or {}).items():
        lo, hi = (list(lim) + [None, None])[:2]
        t = t.between(col, lo, hi)
    req = (job.get("checks") or {}).get("required_columns")
    if req:
        missing = [c for c in req if not t.has(c)]
        if missing:
            raise XlcopyError("required column(s) missing: %s (columns in the file: %s)"
                              % (missing, t.columns))
    if job.get("columns"):
        t = t.select(job["columns"])
    if job.get("rename"):
        t = t.rename(job["rename"])
    tn = job.get("to_numbers")
    if tn:
        t = t.to_numbers() if tn is True else t.to_numbers(tn if isinstance(tn, list) else [tn])
    return t


def run_file(config_path, dry_run=False, log=print):
    config_path = os.path.abspath(config_path)
    base = os.path.dirname(config_path)
    with open(config_path, encoding="utf-8") as f:
        cfg = json.load(f)
    jobs = cfg["jobs"] if isinstance(cfg, dict) else cfg
    return run_jobs(jobs, base, dry_run=dry_run, log=log)


def run_jobs(jobs, base, dry_run=False, log=print):
    """Run a list of job dicts. Relative paths are resolved against `base`."""
    sources = {}
    targets = {}      # output path -> Workbook (so several jobs can fill one file)
    originals = {}    # output path -> path of the file before changes
    results = []
    for n, job in enumerate(jobs, 1):
        label = job.get("name") or "job %d" % n
        unknown = set(job) - _KNOWN
        if unknown:
            raise XlcopyError("%s: unknown setting(s) %s. Check spelling." % (label, sorted(unknown)))
        for req in ("source", "target"):
            if req not in job:
                raise XlcopyError("%s: missing %r" % (label, req))
        t = build_table(job, base, sources)
        log("[%s] %d rows x %d columns from %s" % (label, len(t), len(t.columns), job["source"]))
        if job.get("checks"):
            # required_columns was already checked on the source columns in build_table
            problems = run_checks(t, {k: v for k, v in job["checks"].items() if k != "required_columns"})
            if problems:
                for pr in problems:
                    log("[%s] CHECK FAILED: %s" % (label, pr))
                if not dry_run:
                    raise XlcopyError("%s: %d check(s) failed - nothing was written: %s"
                                      % (label, len(problems), "; ".join(problems)))
            else:
                log("[%s] all checks passed" % label)
        target = _resolve(base, job["target"])
        output = _resolve(base, job.get("output")) or target
        if dry_run:
            log(t.preview(5))
            results.append({"job": label, "rows": len(t)})
            continue
        if output in targets:
            wb = targets[output]
        elif os.path.exists(target):
            wb = Workbook.open(target)
            targets[output] = wb
            originals[output] = target
        else:
            wb = Workbook.new([job.get("target_sheet") or "Sheet1"])
            targets[output] = wb
        sheet = job.get("target_sheet")
        if isinstance(sheet, str) and sheet.casefold() not in [s.casefold() for s in wb.sheet_names]:
            if job.get("create_sheet"):
                wb.add_sheet(sheet)
            else:
                raise XlcopyError("%s: target has no sheet %r (sheets: %s). Add \"create_sheet\": true "
                                  "to create it." % (label, sheet, wb.sheet_names))
        if job.get("clear"):
            wb.clear(sheet, job["clear"])
        mode = job.get("mode", "paste")
        if mode == "paste":
            k = wb.write_table(sheet, t, start=job.get("start", "A1"), header=job.get("write_header", True))
            log("[%s] pasted %d rows at %s!%s" % (label, k, wb.sheet(sheet).name, job.get("start", "A1")))
            results.append({"job": label, "rows_written": k})
        elif mode in ("match_headers", "by_header"):
            rep = wb.write_by_header(sheet, t, header_row=job.get("target_header_row", 1),
                                     key=job.get("key"), add_missing_keys=job.get("add_missing_keys", True))
            log("[%s] matched columns: %s" % (label, rep["matched"]))
            if rep["not_found_in_target"]:
                log("[%s] WARNING not found in target: %s" % (label, rep["not_found_in_target"]))
            log("[%s] rows written: %d (added %d, skipped %d)"
                % (label, rep["rows_written"], rep["rows_added"], rep["rows_skipped"]))
            rep["job"] = label
            results.append(rep)
        else:
            raise XlcopyError("%s: mode must be 'paste' or 'match_headers', not %r" % (label, mode))
        if job.get("backup") and os.path.exists(output) and not os.path.exists(output + ".bak"):
            import shutil
            shutil.copy2(output, output + ".bak")
    refresh_how = {}
    for job in jobs:
        how = job.get("refresh")
        if how:
            out = _resolve(base, job.get("output")) or _resolve(base, job["target"])
            refresh_how[out] = "auto" if how is True else how
    compare_to = {}
    for job in jobs:
        cmp_ = job.get("compare")
        if cmp_:
            out = _resolve(base, job.get("output")) or _resolve(base, job["target"])
            compare_to[out] = cmp_
    # keep the original in memory when we are about to overwrite it
    before = {}
    for output in compare_to:
        if output in originals:
            before[output] = Workbook.open(originals[output])
    for output, wb in targets.items():
        wb.save(output)
        log("saved %s" % output)
    for output, how in refresh_how.items():
        if output in targets:
            from .refresh import refresh
            log(refresh(output, method=how))
    for output, cmp_ in compare_to.items():
        if output not in before:
            log("compare: %s is a new file, nothing to compare with" % output)
            continue
        from .compare import compare, summary_text
        if cmp_ is True:
            stem = os.path.splitext(output)[0]
            rep_path = "%s_changes_%s.xlsx" % (stem, datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
        else:
            rep_path = _resolve(base, cmp_)
        changes = compare(before[output], output, report=rep_path)
        log("compare %s: %d difference(s), report: %s" % (os.path.basename(output), len(changes), rep_path))
        for line in summary_text(changes, max_lines=10).splitlines():
            log("    " + line)
        results.append({"compare": output, "differences": len(changes), "report": rep_path})
    return results
