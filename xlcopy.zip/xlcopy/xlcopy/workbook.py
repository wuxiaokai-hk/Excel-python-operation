"""Read and write .xlsx / .xlsm files with only the Python standard library.

How it works: an .xlsx file is a zip of XML files. We keep every part of the
original file byte-for-byte and only rewrite the <sheetData> block of the
sheets you change (plus tiny edits to the workbook/styles parts when needed).
That is why formatting, charts, other sheets, named ranges and macros survive.
"""

import datetime
import html
import math
import numbers
import os
import posixpath
import re
import shutil
import tempfile
import warnings
import xml.etree.ElementTree as ET
import zipfile
from collections import OrderedDict

from ._cells import (from_serial, make_ref, parse_cell, parse_range, to_serial,
                     norm)
from .table import Table

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"
NS_XML = "http://www.w3.org/XML/1998/namespace"
CT_WORKSHEET = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"
REL_WORKSHEET = NS_REL + "/worksheet"

_DECL_RE = re.compile(r'xmlns(?::([A-Za-z_][\w.\-]*))?\s*=\s*"([^"]*)"')
_PFX = r"(?:[A-Za-z_][\w.\-]*:)?"
_ROOT_WS_RE = re.compile(r"<" + _PFX + r"worksheet\b[^>]*>", re.S)
_SHEETDATA_RE = re.compile(
    r"<(" + _PFX + r")sheetData\b[^>]*?(?:/>|>.*?</\1sheetData\s*>)", re.S)
_DIMENSION_RE = re.compile(r"<" + _PFX + r"dimension\b[^>]*?/>", re.S)
_ILLEGAL_XML = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")

# Built-in number formats that are dates/times.
_BUILTIN_DATE_FMTS = set(range(14, 23)) | {45, 46, 47} | set(range(27, 37)) | set(range(50, 59))


class XlcopyError(Exception):
    """Raised for problems the user can fix (bad sheet name, wrong file type...)."""


class Formula(object):
    """Write a formula instead of a value: wb.set('Sheet1', 'C1', Formula('A1+B1'))."""

    def __init__(self, text):
        self.text = text[1:] if text.startswith("=") else text

    def __repr__(self):
        return "Formula(%r)" % ("=" + self.text)


def _local(tag):
    return tag.rsplit("}", 1)[-1]


def _attr_escape(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("\n", "&#10;").replace("\r", "&#13;")
            .replace("\t", "&#9;"))


def _text_escape(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\r", "&#13;")


def _decode(data):
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("utf-16")


def _is_date_format(code):
    code = re.sub(r'"[^"]*"', "", code)          # quoted text
    code = re.sub(r"\\.", "", code)              # escaped chars
    code = re.sub(r"\[(?!h\]|hh\]|m\]|mm\]|s\]|ss\])[^\]]*\]", "", code, flags=re.I)  # colours etc.
    code = code.split(";")[0]
    return bool(re.search(r"[dmyhs]", code, re.I))


# --------------------------------------------------------------------------- #
# Styles: only what we need (detect date formats, add a date format to a cell)
# --------------------------------------------------------------------------- #
class _Styles(object):
    _XF_RE = re.compile(r"<" + _PFX + r"xf\b[^>]*?(?:/>|>.*?</" + _PFX + r"xf\s*>)", re.S)

    def __init__(self, text):
        self.text = text
        self.dirty = False
        self._clone_cache = {}
        self.custom = {}
        for m in re.finditer(r"<" + _PFX + r"numFmt\b([^>]*)/?>", text):
            attrs = m.group(1)
            i = re.search(r'numFmtId\s*=\s*"(\d+)"', attrs)
            c = re.search(r'formatCode\s*=\s*"([^"]*)"', attrs)
            if i and c:
                self.custom[int(i.group(1))] = html.unescape(c.group(1))
        self._parse_xfs()

    def _cellxfs_span(self):
        m = re.search(r"<(" + _PFX + r")cellXfs\b[^>]*>(.*?)</\1cellXfs\s*>", self.text, re.S)
        return m

    def _parse_xfs(self):
        m = self._cellxfs_span()
        self.xfs = []
        if m:
            self.xfs = [x.group(0) for x in self._XF_RE.finditer(m.group(2))]
        self.date_xf = set()
        for i, xf in enumerate(self.xfs):
            fid = re.search(r'numFmtId\s*=\s*"(\d+)"', xf)
            fid = int(fid.group(1)) if fid else 0
            if fid in _BUILTIN_DATE_FMTS or (fid in self.custom and _is_date_format(self.custom[fid])):
                self.date_xf.add(i)

    def is_date(self, s):
        return s is not None and int(s) in self.date_xf

    def date_style_for(self, s):
        """Return a style index that looks like style `s` but shows a date."""
        base = int(s) if s is not None else 0
        if base in self.date_xf:
            return base
        if base in self._clone_cache:
            return self._clone_cache[base]
        m = self._cellxfs_span()
        if not m or base >= len(self.xfs):
            return None
        xf = self.xfs[base]
        if re.search(r'numFmtId\s*=\s*"\d+"', xf):
            xf = re.sub(r'numFmtId\s*=\s*"\d+"', 'numFmtId="14"', xf, count=1)
        else:
            xf = re.sub(r"<(" + _PFX + r"xf)\b", r'<\1 numFmtId="14"', xf, count=1)
        if re.search(r'applyNumberFormat\s*=\s*"[^"]*"', xf):
            xf = re.sub(r'applyNumberFormat\s*=\s*"[^"]*"', 'applyNumberFormat="1"', xf, count=1)
        else:
            xf = re.sub(r"<(" + _PFX + r"xf)\b", r'<\1 applyNumberFormat="1"', xf, count=1)
        new_index = len(self.xfs)
        inner = m.group(2) + xf
        open_tag = re.match(r"<[^>]*>", m.group(0)).group(0)
        if re.search(r'count\s*=\s*"\d+"', open_tag):
            open_tag = re.sub(r'count\s*=\s*"\d+"', 'count="%d"' % (new_index + 1), open_tag)
        block = open_tag + inner + "</%scellXfs>" % m.group(1)
        self.text = self.text[:m.start()] + block + self.text[m.end():]
        self.dirty = True
        self._parse_xfs()
        self._clone_cache[base] = new_index
        return new_index


# --------------------------------------------------------------------------- #
# One worksheet
# --------------------------------------------------------------------------- #
class _Sheet(object):
    def __init__(self, wb, name, part, data):
        self.wb = wb
        self.name = name
        self.part = part
        self.dirty = False
        text = _decode(data)
        root = _ROOT_WS_RE.search(text)
        if not root:
            raise XlcopyError("Sheet %r is not a normal worksheet (chart sheet or dialog sheet?)" % name)
        root_tag = root.group(0)
        self.uri2prefix = {}
        decls = []
        for m in _DECL_RE.finditer(root_tag):
            self.uri2prefix.setdefault(m.group(2), m.group(1) or "")
            decls.append(m.group(0))
        m = _SHEETDATA_RE.search(text)
        if not m:
            raise XlcopyError("Sheet %r has no <sheetData> section" % name)
        self.head = text[:m.start()]
        self.tail = text[m.end():]
        wrapper = "<xlcopy_wrap %s>%s</xlcopy_wrap>" % (" ".join(decls), m.group(0))
        self.sd = ET.fromstring(wrapper)[0]
        self.ns = self.sd.tag[1:].split("}")[0] if self.sd.tag.startswith("{") else ""
        self._index()
        self._broken_shared = set()

    # ---- indexing --------------------------------------------------------- #
    def _t(self, local):
        return "{%s}%s" % (self.ns, local) if self.ns else local

    def _index(self):
        self.rows = {}
        self._cells = {}
        rnum = 0
        for row in self.sd:
            if _local(row.tag) != "row":
                continue
            r = row.get("r")
            rnum = int(r) if r else rnum + 1
            row.set("r", str(rnum))
            self.rows[rnum] = row
            cells = {}
            cnum = 0
            for c in row:
                if _local(c.tag) != "c":
                    continue
                ref = c.get("r")
                if ref:
                    cnum = parse_cell(ref)[1]
                else:
                    cnum += 1
                    c.set("r", make_ref(rnum, cnum))
                cells[cnum] = c
            self._cells[rnum] = cells
        self._row_keys = sorted(self.rows)

    # ---- reading ---------------------------------------------------------- #
    def _value(self, c, dates=True):
        t = c.get("t", "n")
        if t == "inlineStr":
            is_ = c.find(self._t("is"))
            return self.wb._rich_text(is_) if is_ is not None else ""
        v = c.find(self._t("v"))
        if v is None or v.text is None:
            if t == "str" and c.find(self._t("f")) is not None:
                return ""
            return None
        txt = v.text
        if t == "s":
            return self.wb._shared_strings()[int(txt)]
        if t == "b":
            return txt.strip() in ("1", "true")
        if t in ("str", "e"):
            return txt
        if t == "d":
            try:
                return datetime.datetime.fromisoformat(txt.replace("Z", ""))
            except ValueError:
                return txt
        try:
            x = float(txt)
        except ValueError:
            return txt
        if dates and self.wb._styles() is not None and self.wb._styles().is_date(c.get("s")):
            try:
                return from_serial(x, self.wb.date1904)
            except OverflowError:
                return x
        if x.is_integer() and abs(x) < 2 ** 53 and "e" not in txt.lower() and "." not in txt:
            return int(x)
        return x

    def get(self, row, col, dates=True):
        c = self._cells.get(row, {}).get(col)
        return None if c is None else self._value(c, dates)

    def formula_of(self, c):
        """'=A1+B1' for a formula cell, '=(shared formula)' for a filled-down copy, else None."""
        f = c.find(self._t("f"))
        if f is None:
            return None
        if f.text:
            return "=" + f.text
        if f.get("t") == "shared":
            return "=(shared formula %s)" % f.get("si")
        return "=(formula)"

    def bounds(self):
        """(max_row, max_col) of cells that actually hold a value."""
        mr = mc = 0
        for r, cells in self._cells.items():
            for col, c in cells.items():
                if c.find(self._t("v")) is not None or c.find(self._t("is")) is not None:
                    if r > mr:
                        mr = r
                    if col > mc:
                        mc = col
        return mr, mc

    def iter_values(self, dates=True):
        for r in self._row_keys:
            for col, c in sorted(self._cells[r].items()):
                yield r, col, self._value(c, dates)

    # ---- writing ---------------------------------------------------------- #
    def _row(self, rnum, create=True):
        row = self.rows.get(rnum)
        if row is not None or not create:
            return row
        import bisect
        pos = bisect.bisect_left(self._row_keys, rnum)
        row = ET.Element(self._t("row"), {"r": str(rnum)})
        # position among the <row> children of sheetData
        if pos < len(self._row_keys):
            after = self.rows[self._row_keys[pos]]
            idx = list(self.sd).index(after)
        else:
            idx = len(self.sd)
        self.sd.insert(idx, row)
        self._row_keys.insert(pos, rnum)
        self.rows[rnum] = row
        self._cells[rnum] = {}
        return row

    def _cell(self, rnum, col):
        cells = self._cells.get(rnum)
        if cells is not None and col in cells:
            return cells[col]
        row = self._row(rnum)
        cells = self._cells[rnum]
        c = ET.Element(self._t("c"), {"r": make_ref(rnum, col)})
        later = [k for k in cells if k > col]
        if later:
            idx = list(row).index(cells[min(later)])
            row.insert(idx, c)
        else:
            # keep any non-cell children (extLst) at the end
            idx = len(row)
            for i, ch in enumerate(row):
                if _local(ch.tag) != "c":
                    idx = i
                    break
            row.insert(idx, c)
        cells[col] = c
        # a row-level style (customFormat) applies to new cells in that row
        if row.get("customFormat") in ("1", "true") and row.get("s"):
            c.set("s", row.get("s"))
        return c

    def set(self, row, col, value):
        if not (1 <= row <= 1048576 and 1 <= col <= 16384):
            raise XlcopyError("Cell (%d, %d) is outside the Excel grid" % (row, col))
        exists = col in self._cells.get(row, {})
        if value is None and not exists:
            return
        c = self._cell(row, col)
        self.rows[row].attrib.pop("spans", None)   # optional hint; may be stale now
        self.dirty = True
        old_f = c.find(self._t("f"))
        if old_f is not None:
            self.wb._formulas_touched = True
            if old_f.get("t") == "shared" and old_f.get("ref"):
                self._broken_shared.add(old_f.get("si"))
        for ch in list(c):
            c.remove(ch)
        for a in ("t", "cm", "vm", "ph"):
            c.attrib.pop(a, None)
        if value is None:
            return
        if isinstance(value, Formula):
            f = ET.SubElement(c, self._t("f"))
            f.text = value.text
            self.wb._formulas_touched = True
            return
        if isinstance(value, bool):
            c.set("t", "b")
            ET.SubElement(c, self._t("v")).text = "1" if value else "0"
            return
        if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
            serial = to_serial(value, self.wb.date1904)
            ET.SubElement(c, self._t("v")).text = repr(serial) if isinstance(serial, float) else str(serial)
            styles = self.wb._styles()
            if styles is not None and not isinstance(value, datetime.time):
                s = styles.date_style_for(c.get("s"))
                if s is not None:
                    c.set("s", str(s))
            return
        if isinstance(value, numbers.Number):
            if isinstance(value, numbers.Integral):
                txt = str(int(value))
            else:
                f = float(value)
                if math.isnan(f) or math.isinf(f):
                    return  # leave blank
                txt = repr(f)
                if txt.endswith(".0"):
                    txt = txt[:-2]
            ET.SubElement(c, self._t("v")).text = txt
            return
        s = _ILLEGAL_XML.sub("", str(value))
        c.set("t", "inlineStr")
        is_ = ET.SubElement(c, self._t("is"))
        t = ET.SubElement(is_, self._t("t"))
        t.text = s
        if s != s.strip() or "\n" in s:
            t.set("{%s}space" % NS_XML, "preserve")

    # ---- serialising ------------------------------------------------------ #
    def _qname(self, name, extra):
        if not name.startswith("{"):
            return name
        uri, local = name[1:].split("}", 1)
        if uri == NS_XML:
            return "xml:" + local
        if uri in self.uri2prefix:
            p = self.uri2prefix[uri]
        elif uri in extra:
            p = extra[uri]
        else:
            p = "xc%d" % len(extra)
            extra[uri] = p
        return p + ":" + local if p else local

    def _write_el(self, el, out):
        extra = {}
        tag = self._qname(el.tag, extra)
        attrs = [(self._qname(k, extra), v) for k, v in el.attrib.items()]
        parts = ["<", tag]
        for uri, p in extra.items():
            parts.append(' xmlns:%s="%s"' % (p, _attr_escape(uri)))
        for k, v in attrs:
            parts.append(' %s="%s"' % (k, _attr_escape(v)))
        if len(el) == 0 and not el.text:
            parts.append("/>")
            out.append("".join(parts))
        else:
            parts.append(">")
            out.append("".join(parts))
            if el.text:
                out.append(_text_escape(el.text))
            for ch in el:
                self._write_el(ch, out)
                if ch.tail and ch.tail.strip():
                    out.append(_text_escape(ch.tail))
            out.append("</%s>" % tag)

    def to_bytes(self):
        if self._broken_shared:
            n = 0
            for cells in self._cells.values():
                for c in cells.values():
                    f = c.find(self._t("f"))
                    if f is not None and f.get("t") == "shared" and f.get("si") in self._broken_shared:
                        c.remove(f)
                        n += 1
            if n:
                warnings.warn("Sheet %r: overwrote the anchor of a shared formula; %d dependent "
                              "cells were converted to their last calculated values." % (self.name, n))
            self._broken_shared = set()
        out = []
        self._write_el(self.sd, out)
        head = self.head
        refs = [(r, col) for r, cells in self._cells.items() for col in cells]
        if refs:
            r1 = min(r for r, _ in refs)
            r2 = max(r for r, _ in refs)
            c1 = min(c for _, c in refs)
            c2 = max(c for _, c in refs)
            dim = make_ref(r1, c1) if (r1, c1) == (r2, c2) else "%s:%s" % (make_ref(r1, c1), make_ref(r2, c2))

            def fix(m):
                return re.sub(r'ref\s*=\s*"[^"]*"', 'ref="%s"' % dim, m.group(0))
            head = _DIMENSION_RE.sub(fix, head, count=1)
        return (head + "".join(out) + self.tail).encode("utf-8")


# --------------------------------------------------------------------------- #
# Workbook
# --------------------------------------------------------------------------- #
class Workbook(object):
    """An Excel workbook (.xlsx / .xlsm) held in memory.

    >>> wb = Workbook.open("input.xlsx")
    >>> t = wb.read_table("Data")              # header in row 1
    >>> wb.save("output.xlsx")
    """

    def __init__(self, entries, path=None):
        self.entries = entries          # OrderedDict: part name -> bytes
        self.path = path
        self._sheets = {}
        self._sst = None
        self._styles_obj = None
        self._styles_loaded = False
        self._formulas_touched = False
        self._any_change = False
        self._load_workbook_part()

    # ---- opening / creating ---------------------------------------------- #
    @classmethod
    def open(cls, path):
        path = os.fspath(path)
        if not os.path.exists(path):
            raise XlcopyError("File not found: %s" % path)
        ext = os.path.splitext(path)[1].lower()
        if ext in (".xls", ".xlsb"):
            raise XlcopyError("%s: %s files are not supported. In Excel use File > Save As > "
                              "'Excel Workbook (*.xlsx)' first." % (path, ext))
        if not zipfile.is_zipfile(path):
            raise XlcopyError("%s is not an .xlsx/.xlsm file (it may be password-protected, "
                              "an old .xls file, or a CSV)." % path)
        entries = OrderedDict()
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                entries[info.filename] = z.read(info.filename)
        return cls(entries, path)

    @classmethod
    def new(cls, sheet_names=("Sheet1",)):
        """Create an empty workbook in memory (call .save(path) to write it)."""
        if isinstance(sheet_names, str):
            sheet_names = [sheet_names]
        sheet_names = list(sheet_names) or ["Sheet1"]
        first = _attr_escape(sheet_names[0])
        e = OrderedDict()
        e["[Content_Types].xml"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="%s"/>'
            '</Types>' % CT_WORKSHEET).encode("utf-8")
        e["_rels/.rels"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Relationships xmlns="%s"><Relationship Id="rId1" Type="%s/officeDocument" '
            'Target="xl/workbook.xml"/></Relationships>' % (NS_PKG_REL, NS_REL)).encode("utf-8")
        e["xl/workbook.xml"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<workbook xmlns="%s" xmlns:r="%s"><sheets><sheet name="%s" sheetId="1" r:id="rId1"/>'
            '</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>' % (NS_MAIN, NS_REL, first)).encode("utf-8")
        e["xl/_rels/workbook.xml.rels"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Relationships xmlns="%s">'
            '<Relationship Id="rId1" Type="%s" Target="worksheets/sheet1.xml"/>'
            '<Relationship Id="rId2" Type="%s/styles" Target="styles.xml"/>'
            '</Relationships>' % (NS_PKG_REL, REL_WORKSHEET, NS_REL)).encode("utf-8")
        e["xl/styles.xml"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<styleSheet xmlns="%s">'
            '<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font>'
            '<font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font></fonts>'
            '<fills count="2"><fill><patternFill patternType="none"/></fill>'
            '<fill><patternFill patternType="gray125"/></fill></fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            '<xf numFmtId="14" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
            '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            '</styleSheet>' % NS_MAIN).encode("utf-8")
        e["xl/worksheets/sheet1.xml"] = _empty_sheet_xml()
        wb = cls(e, None)
        for name in sheet_names[1:]:
            wb.add_sheet(name)
        wb._any_change = True
        return wb

    # ---- package plumbing ------------------------------------------------- #
    def _text(self, part):
        return _decode(self.entries[part])

    def _rels(self, part):
        d, f = posixpath.split(part)
        rels_part = posixpath.join(d, "_rels", f + ".rels")
        out = []
        if rels_part not in self.entries:
            return rels_part, out
        root = ET.fromstring(self.entries[rels_part])
        for r in root:
            if r.get("TargetMode") == "External":
                continue
            target = r.get("Target")
            if target.startswith("/"):
                full = target[1:]
            else:
                full = posixpath.normpath(posixpath.join(d, target))
            out.append((r.get("Id"), r.get("Type"), full))
        return rels_part, out

    def _load_workbook_part(self):
        _, root_rels = self._rels("")
        wb_part = None
        for _id, typ, full in root_rels:
            if typ.endswith("/officeDocument"):
                wb_part = full
        if wb_part is None or wb_part not in self.entries:
            raise XlcopyError("This file does not look like an Excel workbook.")
        self.wb_part = wb_part
        self.wb_rels_part, rels = self._rels(wb_part)
        self._rel_by_id = {i: (t, f) for i, t, f in rels}
        root = ET.fromstring(self.entries[wb_part])
        ns = root.tag[1:].split("}")[0]
        self.date1904 = False
        pr = root.find("{%s}workbookPr" % ns)
        if pr is not None and pr.get("date1904") in ("1", "true"):
            self.date1904 = True
        self._sheet_list = []   # (name, part)
        sheets = root.find("{%s}sheets" % ns)
        for s in (sheets if sheets is not None else []):
            rid = None
            for k, v in s.attrib.items():
                if k.endswith("}id"):
                    rid = v
            typ, part = self._rel_by_id.get(rid, (None, None))
            self._sheet_list.append((s.get("name"), part, typ))

    def _shared_strings(self):
        if self._sst is None:
            self._sst = []
            for _id, typ, part in self._rel_by_id_items():
                if typ.endswith("/sharedStrings") and part in self.entries:
                    root = ET.fromstring(self.entries[part])
                    for si in root:
                        self._sst.append(self._rich_text(si))
        return self._sst

    def _rel_by_id_items(self):
        return [(i, t, f) for i, (t, f) in self._rel_by_id.items()]

    def _rich_text(self, el):
        parts = []
        for ch in el:
            name = _local(ch.tag)
            if name == "t":
                parts.append(ch.text or "")
            elif name == "r":
                for t in ch:
                    if _local(t.tag) == "t":
                        parts.append(t.text or "")
        return "".join(parts)

    def _styles(self):
        if not self._styles_loaded:
            self._styles_loaded = True
            for _id, typ, part in self._rel_by_id_items():
                if typ.endswith("/styles") and part in self.entries:
                    self._styles_part = part
                    self._styles_obj = _Styles(self._text(part))
        return self._styles_obj

    # ---- sheets ----------------------------------------------------------- #
    @property
    def sheet_names(self):
        return [n for n, _p, _t in self._sheet_list]

    def _resolve_sheet(self, sheet):
        names = self.sheet_names
        if sheet is None:
            sheet = 0
        if isinstance(sheet, int):
            if not -len(names) <= sheet < len(names):
                raise XlcopyError("Sheet index %d out of range; sheets are %s" % (sheet, names))
            return self._sheet_list[sheet]
        for entry in self._sheet_list:
            if entry[0] == sheet:
                return entry
        for entry in self._sheet_list:
            if entry[0].strip().casefold() == str(sheet).strip().casefold():
                return entry
        raise XlcopyError("No sheet named %r. Sheets in this file: %s" % (sheet, names))

    def sheet(self, sheet=None):
        name, part, typ = self._resolve_sheet(sheet)
        if typ is not None and not typ.endswith("/worksheet"):
            raise XlcopyError("%r is a chart sheet, not a worksheet." % name)
        if part not in self._sheets:
            self._sheets[part] = _Sheet(self, name, part, self.entries[part])
        return self._sheets[part]

    def add_sheet(self, name):
        """Add an empty worksheet at the end and return its name."""
        name = str(name)
        if not name or len(name) > 31 or re.search(r"[\[\]:*?/\\]", name) or name.startswith("'"):
            raise XlcopyError("Invalid sheet name %r (max 31 chars, none of []:*?/\\)" % name)
        if name.casefold() in [n.casefold() for n in self.sheet_names]:
            raise XlcopyError("A sheet named %r already exists" % name)
        wb_dir = posixpath.dirname(self.wb_part)
        n = 1
        while posixpath.join(wb_dir, "worksheets", "sheet%d.xml" % n) in self.entries:
            n += 1
        part = posixpath.join(wb_dir, "worksheets", "sheet%d.xml" % n)
        self.entries[part] = _empty_sheet_xml()
        # relationship
        rels_text = self._text(self.wb_rels_part)
        ids = re.findall(r'Id\s*=\s*"([^"]*)"', rels_text)
        k = len(ids) + 1
        while "rId%d" % k in ids:
            k += 1
        rid = "rId%d" % k
        target = posixpath.relpath(part, wb_dir or ".")
        rels_text = re.sub(r"(</(?:[\w]+:)?Relationships\s*>)",
                           '<Relationship Id="%s" Type="%s" Target="%s"/>\\1' % (rid, REL_WORKSHEET, target),
                           rels_text, count=1)
        self.entries[self.wb_rels_part] = rels_text.encode("utf-8")
        # workbook.xml
        wb_text = self._text(self.wb_part)
        sheet_ids = [int(x) for x in re.findall(r"<" + _PFX + r'sheet\b[^>]*?sheetId\s*=\s*"(\d+)"', wb_text)]
        sid = max(sheet_ids or [0]) + 1
        root_tag = re.search(r"<" + _PFX + r"workbook\b[^>]*>", wb_text).group(0)
        rpfx = None
        for m in _DECL_RE.finditer(root_tag):
            if m.group(2) == NS_REL and m.group(1):
                rpfx = m.group(1)
        sp = re.search(r"<(" + _PFX + r")sheets\b", wb_text).group(1)
        if rpfx:
            el = '<%ssheet name="%s" sheetId="%d" %s:id="%s"/>' % (sp, _attr_escape(name), sid, rpfx, rid)
        else:
            el = '<%ssheet name="%s" sheetId="%d" xmlns:xr_="%s" xr_:id="%s"/>' % (
                sp, _attr_escape(name), sid, NS_REL, rid)
        wb_text = re.sub(r"(</" + re.escape(sp) + r"sheets\s*>)", lambda m: el + m.group(1), wb_text, count=1)
        self.entries[self.wb_part] = wb_text.encode("utf-8")
        # content types
        ct = self._text("[Content_Types].xml")
        ct = re.sub(r"(</(?:[\w]+:)?Types\s*>)",
                    '<Override PartName="/%s" ContentType="%s"/>\\1' % (part, CT_WORKSHEET), ct, count=1)
        self.entries["[Content_Types].xml"] = ct.encode("utf-8")
        self._any_change = True
        self._load_workbook_part()
        return name

    # ---- reading ---------------------------------------------------------- #
    def get(self, sheet, ref, dates=True):
        """Value of one cell, e.g. wb.get('Data', 'B3')."""
        r, c = parse_cell(ref)
        return self.sheet(sheet).get(r, c, dates)

    def read_rows(self, sheet=None, range=None, dates=True):
        """Return a list of rows (lists) for a sheet or a range like 'A1:F200'.

        Without `range`, the grid starts at A1 so rows[0][0] is cell A1.
        Empty cells are None. Formulas give their last calculated value.
        """
        sh = self.sheet(sheet)
        max_r, max_c = sh.bounds()
        if range:
            r1, c1, r2, c2 = parse_range(range)
            r2 = max_r if r2 is None else r2
            c2 = max_c if c2 is None else c2
        else:
            r1, c1, r2, c2 = 1, 1, max_r, max_c
        if r2 < r1 or c2 < c1:
            return []
        width = c2 - c1 + 1
        rows = [[None] * width for _ in builtins_range(r2 - r1 + 1)]
        for r in sh._row_keys:
            if r < r1 or r > r2:
                continue
            for col, c in sh._cells[r].items():
                if c1 <= col <= c2:
                    rows[r - r1][col - c1] = sh._value(c, dates)
        return rows

    def read_table(self, sheet=None, header_row=1, range=None, dates=True, drop_empty=True):
        """Read a sheet into a Table using the row `header_row` as column names.

        If `range` is given (e.g. 'B3:H500'), header_row counts from the top of
        that range (1 = first row of the range).
        """
        rows = self.read_rows(sheet, range, dates)
        if not range and rows:
            # trim empty leading columns so a table that starts in column B still works
            pass
        t = Table.from_rows(rows, header_row=header_row)
        if drop_empty:
            t = t.drop_empty_rows()
        return t

    # ---- writing ---------------------------------------------------------- #
    def set(self, sheet, ref, value):
        """Write one value, e.g. wb.set('Input', 'C5', 1.23). Keeps the cell's formatting."""
        r, c = parse_cell(ref)
        self.sheet(sheet).set(r, c, value)
        self._any_change = True

    def write_rows(self, sheet, start, rows):
        """Paste a list of rows starting at cell `start` (e.g. 'B2'). Values only."""
        sh = self.sheet(sheet)
        r0, c0 = parse_cell(start)
        n = 0
        for i, row in enumerate(rows):
            for j, v in enumerate(row):
                sh.set(r0 + i, c0 + j, v)
            n += 1
        self._any_change = True
        return n

    def write_table(self, sheet, table, start="A1", header=True):
        """Paste a Table at `start`; with header=True the column names go first."""
        return self.write_rows(sheet, start, table.to_rows(header=header))

    def clear(self, sheet, range):
        """Empty the values in a range (formatting is kept), e.g. wb.clear('Input', 'A2:H500')."""
        sh = self.sheet(sheet)
        r1, c1, r2, c2 = parse_range(range)
        max_r, max_c = sh.bounds()
        r2 = max_r if r2 is None else r2
        c2 = max_c if c2 is None else c2
        for r in list(sh._row_keys):
            if r1 <= r <= r2:
                for col in list(sh._cells[r]):
                    if c1 <= col <= c2:
                        sh.set(r, col, None)
        self._any_change = True

    def header_map(self, sheet, header_row=1):
        """{column header: column number} for one row of a sheet."""
        sh = self.sheet(sheet)
        out = OrderedDict()
        for col, c in sorted(sh._cells.get(header_row, {}).items()):
            v = sh._value(c)
            if v is not None and str(v).strip() != "":
                out.setdefault(v, col)
        return out

    def write_by_header(self, sheet, table, header_row=1, key=None, add_missing_keys=True):
        """Write each Table column under the destination column with the same header.

        Headers are matched ignoring case and surrounding spaces. Columns of the
        destination that are not in the table are left untouched.

        key: optional column name used to line up rows (e.g. 'Date'). Rows whose
        key is not yet in the destination are appended at the bottom when
        add_missing_keys=True, otherwise skipped.

        Returns a small report dict.
        """
        sh = self.sheet(sheet)
        dest = OrderedDict((norm(h), c) for h, c in self.header_map(sheet, header_row).items())
        matched, unmatched = [], []
        for j, name in enumerate(table.columns):
            c = dest.get(norm(name))
            if c is None:
                unmatched.append(name)
            else:
                matched.append((j, c, name))
        report = {"matched": [m[2] for m in matched], "not_found_in_target": unmatched,
                  "rows_written": 0, "rows_added": 0, "rows_skipped": 0}
        if not matched:
            raise XlcopyError("None of the columns %s were found in row %d of sheet %r. Headers there are: %s"
                              % (table.columns, header_row, sh.name, list(self.header_map(sheet, header_row))))
        if key is None:
            for i, row in enumerate(table.rows):
                for j, c, _ in matched:
                    sh.set(header_row + 1 + i, c, row[j])
            report["rows_written"] = len(table.rows)
        else:
            kj = table.index(key)
            kc = dest.get(norm(key))
            if kc is None:
                raise XlcopyError("Key column %r not found in row %d of sheet %r" % (key, header_row, sh.name))
            where = {}
            last = header_row
            for r in sh._row_keys:
                if r <= header_row:
                    continue
                c = sh._cells[r].get(kc)
                v = sh._value(c) if c is not None else None
                if v is not None and str(v).strip() != "":
                    where.setdefault(norm(v), r)
                    last = max(last, r)
            for row in table.rows:
                k = norm(row[kj])
                if k is None:
                    report["rows_skipped"] += 1
                    continue
                r = where.get(k)
                if r is None:
                    if not add_missing_keys:
                        report["rows_skipped"] += 1
                        continue
                    last += 1
                    r = where[k] = last
                    sh.set(r, kc, row[kj])
                    report["rows_added"] += 1
                for j, c, _ in matched:
                    if j != kj:
                        sh.set(r, c, row[j])
                report["rows_written"] += 1
        self._any_change = True
        return report

    # ---- saving ----------------------------------------------------------- #
    def _finalise(self):
        out = OrderedDict(self.entries)
        for part, sh in self._sheets.items():
            if sh.dirty:
                out[part] = sh.to_bytes()
        if self._styles_obj is not None and self._styles_obj.dirty:
            out[self._styles_part] = self._styles_obj.text.encode("utf-8")
        if any(sh.dirty for sh in self._sheets.values()):
            # Make Excel recalculate formulas that depend on the pasted values,
            # and drop the calculation-order cache (Excel rebuilds it).
            wb_text = _decode(out[self.wb_part])
            m = re.search(r"<(" + _PFX + r")calcPr\b[^>]*?/?>", wb_text)
            if m:
                tag = m.group(0)
                if "fullCalcOnLoad" in tag:
                    new = re.sub(r'fullCalcOnLoad\s*=\s*"[^"]*"', 'fullCalcOnLoad="1"', tag)
                else:
                    new = re.sub(r"(/?>)$", r' fullCalcOnLoad="1"\1', tag)
                wb_text = wb_text[:m.start()] + new + wb_text[m.end():]
            else:
                p = re.search(r"<(" + _PFX + r")workbook\b", wb_text).group(1)
                anchor = re.search(r"</" + re.escape(p) + r"definedNames\s*>|<" + re.escape(p)
                                   + r"definedNames\s*/>|</" + re.escape(p) + r"sheets\s*>", wb_text)
                if anchor:
                    pos = anchor.end()
                    if "definedNames" not in anchor.group(0):
                        dn = re.search(r"</" + re.escape(p) + r"definedNames\s*>", wb_text)
                        if dn:
                            pos = dn.end()
                    wb_text = wb_text[:pos] + '<%scalcPr fullCalcOnLoad="1"/>' % p + wb_text[pos:]
            out[self.wb_part] = wb_text.encode("utf-8")
            calc = [f for _i, t, f in self._rel_by_id_items() if t.endswith("/calcChain")]
            for part in calc:
                out.pop(part, None)
                rels = _decode(out[self.wb_rels_part])
                rels = re.sub(r"<(?:[\w]+:)?Relationship\b[^>]*calcChain[^>]*/>", "", rels)
                out[self.wb_rels_part] = rels.encode("utf-8")
                ct = _decode(out["[Content_Types].xml"])
                ct = re.sub(r'<(?:[\w]+:)?Override\b[^>]*PartName="/%s"[^>]*/>' % re.escape(part), "", ct)
                out["[Content_Types].xml"] = ct.encode("utf-8")
        return out

    def save(self, path=None):
        """Write the workbook. Saves over the original file if `path` is omitted."""
        path = os.fspath(path) if path is not None else self.path
        if path is None:
            raise XlcopyError("No file name given to save()")
        out = self._finalise()
        folder = os.path.dirname(os.path.abspath(path))
        if not os.path.isdir(folder):
            os.makedirs(folder)
        fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=folder)
        os.close(fd)
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
                for name, data in out.items():
                    z.writestr(name, data)
            try:
                os.replace(tmp, path)
            except PermissionError:
                raise XlcopyError("Cannot write %s - is it open in Excel? Close it and try again." % path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        self.path = path
        return path


builtins_range = range


def _empty_sheet_xml():
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<worksheet xmlns="%s" xmlns:r="%s"><dimension ref="A1"/>'
            '<sheetData/><pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>'
            '</worksheet>' % (NS_MAIN, NS_REL)).encode("utf-8")


def backup(path):
    """Copy `path` to `path.bak` (overwriting an older backup)."""
    dst = path + ".bak"
    shutil.copy2(path, dst)
    return dst
