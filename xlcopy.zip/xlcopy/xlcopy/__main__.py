"""Command line: python -m xlcopy <command> ...

  python -m xlcopy sheets  FILE
  python -m xlcopy headers FILE [--sheet NAME] [--header-row N]
  python -m xlcopy preview FILE [--sheet NAME] [--header-row N] [-n 10] [--columns "A,B"]
  python -m xlcopy copy    --src FILE --dst FILE [--columns "Date,GDP"] [--where "Region=ON,BC"] ...
  python -m xlcopy run     JOBS.json [--dry-run]
"""

import argparse
import os
import sys

if __package__ in (None, ""):
    # allow `python xlcopy/__main__.py` as well as `python -m xlcopy`
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    __package__ = "xlcopy"

from . import Workbook, XlcopyError, write_table  # noqa: E402
from .jobs import run_file  # noqa: E402


def _cols(s):
    return [c.strip() for c in s.split(",") if c.strip()] if s else None


def _sheet(s):
    if s is None:
        return None
    return int(s) if s.isdigit() else s


def main(argv=None):
    p = argparse.ArgumentParser(prog="python -m xlcopy",
                                description="Filter and copy Excel data (standard library only).")
    sub = p.add_subparsers(dest="cmd")

    a = sub.add_parser("sheets", help="list sheet names")
    a.add_argument("file")

    a = sub.add_parser("headers", help="list column headers of a sheet")
    a.add_argument("file")
    a.add_argument("--sheet")
    a.add_argument("--header-row", type=int, default=1)

    a = sub.add_parser("preview", help="show the first rows of a sheet")
    a.add_argument("file")
    a.add_argument("--sheet")
    a.add_argument("--header-row", type=int, default=1)
    a.add_argument("--columns")
    a.add_argument("-n", type=int, default=10)

    a = sub.add_parser("copy", help="copy columns from one workbook to another")
    a.add_argument("--src", required=True)
    a.add_argument("--src-sheet")
    a.add_argument("--header-row", type=int, default=1)
    a.add_argument("--columns", help='comma separated, e.g. "Date,GDP,CPI"')
    a.add_argument("--where", action="append", default=[],
                   help='filter rows, e.g. "Region=ON,BC" (repeatable)')
    a.add_argument("--dst", required=True)
    a.add_argument("--dst-sheet")
    a.add_argument("--start", default="A1")
    a.add_argument("--no-header", action="store_true")
    a.add_argument("--by-header", action="store_true",
                   help="write under matching headers in the target instead of pasting a block")
    a.add_argument("--key", help="with --by-header: column used to line up rows, e.g. Date")
    a.add_argument("--clear", help='range to empty first, e.g. "A2:Z5000"')
    a.add_argument("--out", help="save to a new file instead of overwriting --dst")
    a.add_argument("--create-sheet", action="store_true")

    a = sub.add_parser("refresh", help="recalculate formulas and Refresh All (pivots, queries)")
    a.add_argument("file")
    a.add_argument("--method", default="auto", choices=["auto", "excel", "on_open"],
                   help="excel = refresh now in a hidden Excel (Windows); "
                        "on_open = Excel refreshes when the file is next opened; auto = excel if possible")
    a.add_argument("--out", help="save to a new file instead of overwriting")
    a.add_argument("--timeout", type=int, default=900, help="seconds to wait for Excel")

    a = sub.add_parser("compare", help="compare an original and a changed workbook")
    a.add_argument("old")
    a.add_argument("new")
    a.add_argument("--sheet", action="append", help="only this sheet (repeatable)")
    a.add_argument("--report", help="write the differences to this .xlsx file")
    a.add_argument("--tolerance", type=float, default=1e-9, help="numbers closer than this are equal")
    a.add_argument("--formulas-only", action="store_true",
                   help="for formula cells compare only the formula text, not the cached result")

    a = sub.add_parser("run", help="run jobs from a JSON file")
    a.add_argument("config")
    a.add_argument("--dry-run", action="store_true", help="show what would be copied; write nothing")

    args = p.parse_args(argv)
    if not args.cmd:
        p.print_help()
        return 1
    try:
        if args.cmd == "sheets":
            for n in Workbook.open(args.file).sheet_names:
                print(n)
        elif args.cmd == "headers":
            wb = Workbook.open(args.file)
            for h, c in wb.header_map(_sheet(args.sheet), args.header_row).items():
                from ._cells import index_to_col
                print("%-4s %s" % (index_to_col(c), h))
        elif args.cmd == "preview":
            t = Workbook.open(args.file).read_table(_sheet(args.sheet), header_row=args.header_row)
            if args.columns:
                t = t.select(_cols(args.columns))
            print("%d rows x %d columns" % (len(t), len(t.columns)))
            t.show(args.n)
        elif args.cmd == "copy":
            t = Workbook.open(args.src).read_table(_sheet(args.src_sheet), header_row=args.header_row)
            for w in args.where:
                if "=" not in w:
                    raise XlcopyError('--where needs the form "Column=value1,value2"')
                col, vals = w.split("=", 1)
                t = t.where(col.strip(), _cols(vals))
            if args.columns:
                t = t.select(_cols(args.columns))
            res = write_table(args.dst, t, sheet=_sheet(args.dst_sheet), start=args.start,
                              header=not args.no_header, out=args.out, by_header=args.by_header,
                              key=args.key, clear=args.clear, create_sheet=args.create_sheet)
            print("copied %d rows x %d columns -> %s" % (len(t), len(t.columns), args.out or args.dst))
            if isinstance(res, dict) and res.get("not_found_in_target"):
                print("WARNING: not found in target:", res["not_found_in_target"])
        elif args.cmd == "refresh":
            from .refresh import refresh
            print(refresh(args.file, out=args.out, method=args.method, timeout=args.timeout))
        elif args.cmd == "compare":
            from .compare import compare, summary_text
            ch = compare(args.old, args.new, sheets=args.sheet, tolerance=args.tolerance,
                         report=args.report, ignore_formula_values=args.formulas_only)
            print("%d difference(s)" % len(ch))
            print(summary_text(ch, max_lines=40))
            if args.report:
                print("report written to %s" % args.report)
        elif args.cmd == "run":
            run_file(args.config, dry_run=args.dry_run)
    except (XlcopyError, KeyError, ValueError, OSError) as e:
        msg = e.args[0] if isinstance(e, KeyError) and e.args else e
        print("ERROR: %s" % msg, file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
