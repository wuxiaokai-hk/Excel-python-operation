"""Compare two versions of a workbook cell by cell and report what changed.

    diffs = xlcopy.compare("model_before.xlsx", "model_after.xlsx",
                           report="changes.xlsx")

Each difference says which sheet and cell changed, the row label (column A) and
column header (row 1) for context, the old and new value, and the change for numbers.
"""

import datetime
import os
from collections import OrderedDict

from ._cells import make_ref
from .workbook import Workbook


class Change(object):
    __slots__ = ("sheet", "row", "col", "cell", "row_label", "col_header", "old", "new",
                 "kind", "diff", "pct")

    def __init__(self, **kw):
        for k in self.__slots__:
            setattr(self, k, kw.get(k))

    def as_row(self):
        return [self.sheet, self.cell, self.row_label, self.col_header, self.old, self.new,
                self.kind, self.diff, self.pct]

    def __repr__(self):
        return "%s!%s %s: %r -> %r" % (self.sheet, self.cell, self.kind, self.old, self.new)


COLUMNS = ["Sheet", "Cell", "Row label", "Column header", "Old value", "New value",
           "Change", "Difference", "% change"]


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _same(a, b, tol):
    if a is None and isinstance(b, str) and b == "":
        return True
    if b is None and isinstance(a, str) and a == "":
        return True
    if _num(a) and _num(b):
        return abs(a - b) <= tol
    return a == b


def _cells(wb, sheet):
    """{(row, col): (value, formula)} for every cell that has a value or formula."""
    sh = wb.sheet(sheet)
    out = {}
    for r in sh._row_keys:
        for col, c in sh._cells[r].items():
            v = sh._value(c)
            f = sh.formula_of(c)
            if v is not None or f is not None:
                out[(r, col)] = (v, f)
    return out


def _label(cells, row, col, header_row, label_col):
    rl = cells.get((row, label_col), (None, None))[0] if label_col else None
    ch = cells.get((header_row, col), (None, None))[0] if header_row else None
    return rl, ch


def compare(old, new, sheets=None, tolerance=1e-9, header_row=1, label_col=1,
            report=None, ignore_formula_values=False):
    """Compare two workbooks (paths or Workbook objects).

    sheets:     list of sheet names to compare (default: all sheets in either file)
    tolerance:  numbers closer than this count as equal
    header_row / label_col: where to take the column header / row label shown in the report
                (set to None to leave them out)
    report:     path of an .xlsx report to write (optional)
    ignore_formula_values: only compare formula text for formula cells (useful when the
                new file has not been recalculated yet)

    Returns a list of Change objects.
    """
    wa = old if isinstance(old, Workbook) else Workbook.open(old)
    wb = new if isinstance(new, Workbook) else Workbook.open(new)
    names_a, names_b = wa.sheet_names, wb.sheet_names
    if sheets is None:
        sheets = names_a + [n for n in names_b if n not in names_a]
    elif isinstance(sheets, str):
        sheets = [sheets]
    changes = []
    for name in sheets:
        in_a, in_b = name in names_a, name in names_b
        if not in_a or not in_b:
            changes.append(Change(sheet=name, cell="", kind="sheet added" if in_b else "sheet removed"))
            continue
        try:
            ca, cb = _cells(wa, name), _cells(wb, name)
        except Exception as e:  # chart sheets etc.
            changes.append(Change(sheet=name, cell="", kind="not compared (%s)" % e))
            continue
        for key in sorted(set(ca) | set(cb)):
            va, fa = ca.get(key, (None, None))
            vb, fb = cb.get(key, (None, None))
            kind = None
            if fa != fb:
                if fa and not fb:
                    kind = "formula replaced by value"
                elif fb and not fa:
                    kind = "formula added" if va is None else "value replaced by formula"
                else:
                    kind = "formula changed"
                va_show, vb_show = (fa if fa else va), (fb if fb else vb)
            else:
                if fa and ignore_formula_values:
                    continue
                if _same(va, vb, tolerance):
                    continue
                if va is None:
                    kind = "added"
                elif vb is None:
                    kind = "deleted"
                else:
                    kind = "changed"
                if fa:
                    kind += " (formula result)"
                va_show, vb_show = va, vb
            r, c = key
            rl, ch = _label(cb if key in cb else ca, r, c, header_row, label_col)
            if rl is None:
                rl = _label(ca, r, c, header_row, label_col)[0]
            diff = pct = None
            if _num(va) and _num(vb):
                diff = vb - va
                pct = round(diff / abs(va), 12) if va else None
                diff = round(diff, 12)
            changes.append(Change(sheet=name, row=r, col=c, cell=make_ref(r, c), row_label=rl,
                                  col_header=ch, old=va_show, new=vb_show, kind=kind,
                                  diff=diff, pct=pct))
    if report:
        write_report(changes, report, wa, wb)
    return changes


def summarize(changes):
    """{sheet: {change kind: count}}"""
    out = OrderedDict()
    for ch in changes:
        out.setdefault(ch.sheet, OrderedDict())
        out[ch.sheet][ch.kind] = out[ch.sheet].get(ch.kind, 0) + 1
    return out


def summary_text(changes, max_lines=20):
    if not changes:
        return "No differences."
    lines = []
    for sheet, kinds in summarize(changes).items():
        lines.append("%s: %s" % (sheet, ", ".join("%d %s" % (n, k) for k, n in kinds.items())))
    lines.append("")
    for ch in changes[:max_lines]:
        ctx = " / ".join(_fmt(x).strip("'") for x in (ch.row_label, ch.col_header) if x is not None)
        lines.append("  %s!%-7s %-26s %s -> %s%s" % (
            ch.sheet, ch.cell, ch.kind, _fmt(ch.old), _fmt(ch.new), ("   [%s]" % ctx) if ctx else ""))
    if len(changes) > max_lines:
        lines.append("  ... %d more (see the report)" % (len(changes) - max_lines))
    return "\n".join(lines)


def _fmt(v):
    if v is None:
        return "(empty)"
    if isinstance(v, datetime.datetime) and v.hour == v.minute == v.second == 0:
        return v.date().isoformat()
    if isinstance(v, float):
        return "%.6g" % v
    return repr(v) if isinstance(v, str) else str(v)


def write_report(changes, path, old_wb=None, new_wb=None):
    """Write the changes to an .xlsx file with a Summary and a Changes sheet."""
    rep = Workbook.new(["Summary", "Changes"])
    rows = [["Compared", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
            ["Original file", getattr(old_wb, "path", None) or ""],
            ["Changed file", getattr(new_wb, "path", None) or ""],
            ["Total differences", len(changes)], [], ["Sheet", "Change", "Count"]]
    for sheet, kinds in summarize(changes).items():
        for k, n in kinds.items():
            rows.append([sheet, k, n])
    rep.write_rows("Summary", "A1", rows)
    rep.write_rows("Changes", "A1", [COLUMNS] + [ch.as_row() for ch in changes])
    # bold headers (style 2 in a new workbook is bold)
    for sheet, r, n in (("Summary", 6, 3), ("Changes", 1, len(COLUMNS))):
        sh = rep.sheet(sheet)
        for c in range(1, n + 1):
            sh._cell(r, c).set("s", "2")
    folder = os.path.dirname(os.path.abspath(path))
    if not os.path.isdir(folder):
        os.makedirs(folder)
    rep.save(path)
    return path
