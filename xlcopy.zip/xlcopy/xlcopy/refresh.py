"""Refresh a workbook: recalculate formulas, refresh data connections/queries and pivot tables.

Two ways, both standard-library only:

refresh_with_excel(path)  - Windows + Excel installed. Opens the file in a hidden
                            Excel (through a small VBScript run by `cscript`, which
                            is part of Windows), does Data > Refresh All, recalculates,
                            saves and closes. Afterwards xlcopy reads the NEW values.

mark_refresh_on_open(path) - Any computer. Edits the file so that Excel recalculates
                            all formulas and refreshes pivot tables and data
                            connections the next time someone opens it. Nothing is
                            recalculated until then.

refresh(path)              - uses Excel when available, otherwise marks the file.
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile

from .workbook import Workbook, XlcopyError, _decode

_VBS = r'''
Option Explicit
Dim src, dst, xl, wb, conn, ws, qt, lo, fmt, ext, errMsg
src = WScript.Arguments(0)
dst = WScript.Arguments(1)
errMsg = ""

On Error Resume Next
Set xl = CreateObject("Excel.Application")
If Err.Number <> 0 Then
    WScript.Echo "ERROR: Excel is not available on this computer (" & Err.Description & ")"
    WScript.Quit 3
End If
xl.Visible = False
xl.DisplayAlerts = False
xl.AskToUpdateLinks = False
xl.ScreenUpdating = False
Err.Clear

Set wb = xl.Workbooks.Open(src, 3, False)
If Err.Number <> 0 Then
    errMsg = "could not open the file (" & Err.Description & ")"
ElseIf wb.ReadOnly Then
    errMsg = "the file opened read-only - is it open in Excel or by someone else?"
End If

If errMsg = "" Then
    ' make queries finish before we save
    For Each conn In wb.Connections
        conn.OLEDBConnection.BackgroundQuery = False
        conn.ODBCConnection.BackgroundQuery = False
        Err.Clear
    Next
    For Each ws In wb.Worksheets
        For Each qt In ws.QueryTables
            qt.BackgroundQuery = False
        Next
        For Each lo In ws.ListObjects
            lo.QueryTable.BackgroundQuery = False
        Next
        Err.Clear
    Next
    Err.Clear
    wb.RefreshAll
    If Err.Number <> 0 Then errMsg = "Refresh All failed (" & Err.Description & ")"
    Err.Clear
    xl.CalculateUntilAsyncQueriesDone
    Err.Clear
    xl.CalculateFull
    Err.Clear
End If

If errMsg = "" Then
    If dst = "" Or LCase(dst) = LCase(src) Then
        wb.Save
    Else
        ext = LCase(Mid(dst, InStrRev(dst, ".") + 1))
        fmt = 51
        If ext = "xlsm" Then fmt = 52
        wb.SaveAs dst, fmt
    End If
    If Err.Number <> 0 Then errMsg = "could not save (" & Err.Description & ")"
End If

If Not IsEmpty(wb) Then wb.Close False
xl.Quit
Set wb = Nothing
Set xl = Nothing

If errMsg <> "" Then
    WScript.Echo "ERROR: " & errMsg
    WScript.Quit 2
End If
WScript.Echo "OK"
WScript.Quit 0
'''


def excel_available():
    """True on Windows when `cscript` exists (Excel itself is checked when we run)."""
    return sys.platform.startswith("win") and shutil.which("cscript") is not None


def refresh_with_excel(path, out=None, timeout=900):
    """Open `path` in a hidden Excel, Refresh All + full recalculation, save.

    out:     save to another file instead of overwriting `path`.
    timeout: seconds to wait (slow queries may need more).
    Raises XlcopyError if Excel is missing or something fails.
    """
    if not sys.platform.startswith("win"):
        raise XlcopyError("refresh_with_excel needs Windows with Excel installed. "
                          "Use mark_refresh_on_open() instead.")
    src = os.path.abspath(os.fspath(path))
    if not os.path.exists(src):
        raise XlcopyError("File not found: %s" % src)
    dst = os.path.abspath(os.fspath(out)) if out else ""
    if dst and os.path.exists(dst):
        os.remove(dst)            # Excel would otherwise ask before overwriting
    fd, script = tempfile.mkstemp(suffix=".vbs")
    os.close(fd)
    try:
        with open(script, "w", encoding="ascii") as f:
            f.write(_VBS)
        try:
            r = subprocess.run(["cscript", "//nologo", "//E:vbscript", script, src, dst],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout,
                               universal_newlines=True)
        except subprocess.TimeoutExpired:
            raise XlcopyError("Excel refresh did not finish within %d seconds. A hidden EXCEL.EXE may "
                              "still be running - end it in Task Manager." % timeout)
        except FileNotFoundError:
            raise XlcopyError("cscript was not found, so Excel cannot be controlled from here. "
                              "Use mark_refresh_on_open() instead.")
        msg = (r.stdout or "").strip()
        if r.returncode != 0 or not msg.endswith("OK"):
            raise XlcopyError("Excel refresh failed: %s" % (msg or "exit code %d" % r.returncode))
    finally:
        os.remove(script)
    return dst or src


def mark_refresh_on_open(path, out=None):
    """Flag the file so Excel recalculates and refreshes pivots/connections when opened.

    Returns a short description of what was flagged.
    """
    wb = Workbook.open(path)
    changed = []
    e = wb.entries

    # 1. formulas: full recalculation on load
    txt = _decode(e[wb.wb_part])
    m = re.search(r"<((?:[A-Za-z_][\w.\-]*:)?)calcPr\b[^>]*?/?>", txt)
    if m:
        tag = m.group(0)
        if "fullCalcOnLoad" in tag:
            new = re.sub(r'fullCalcOnLoad\s*=\s*"[^"]*"', 'fullCalcOnLoad="1"', tag)
        else:
            new = re.sub(r"(/?>)$", r' fullCalcOnLoad="1"\1', tag)
        txt = txt[:m.start()] + new + txt[m.end():]
    else:
        p = re.search(r"<((?:[A-Za-z_][\w.\-]*:)?)workbook\b", txt).group(1)
        anchor = (re.search(r"</%sdefinedNames\s*>" % re.escape(p), txt)
                  or re.search(r"</%ssheets\s*>" % re.escape(p), txt))
        txt = txt[:anchor.end()] + '<%scalcPr fullCalcOnLoad="1"/>' % p + txt[anchor.end():]
    e[wb.wb_part] = txt.encode("utf-8")
    changed.append("formulas")

    def flag(part, tag_local):
        t = _decode(e[part])
        pat = re.compile(r"<((?:[A-Za-z_][\w.\-]*:)?)%s\b[^>]*?>" % tag_local)
        n = [0]

        def fix(mm):
            tag = mm.group(0)
            n[0] += 1
            if "refreshOnLoad" in tag:
                return re.sub(r'refreshOnLoad\s*=\s*"[^"]*"', 'refreshOnLoad="1"', tag)
            close = "/>" if tag.endswith("/>") else ">"
            return tag[:-len(close)].rstrip() + ' refreshOnLoad="1"' + close
        t = pat.sub(fix, t)
        e[part] = t.encode("utf-8")
        return n[0]

    pivots = conns = 0
    for name in list(e):
        low = name.lower()
        if low.startswith("xl/pivotcache/pivotcachedefinition") and low.endswith(".xml"):
            pivots += flag(name, "pivotCacheDefinition")
        elif low == "xl/connections.xml":
            conns += flag(name, "connection")
    if pivots:
        changed.append("%d pivot table cache(s)" % pivots)
    if conns:
        changed.append("%d data connection(s)" % conns)
    wb.save(out or path)
    return "will refresh on open: " + ", ".join(changed)


def refresh(path, out=None, method="auto", timeout=900):
    """Refresh a workbook.

    method="excel"   - real refresh now through Excel (Windows).
    method="on_open" - flag the file; Excel refreshes when it is next opened.
    method="auto"    - try Excel; if it is not available, fall back to on_open.
    Returns a message saying what happened.
    """
    method = (method or "auto").lower().replace("-", "_")
    if method in ("excel", "now"):
        return "refreshed in Excel: %s" % refresh_with_excel(path, out, timeout)
    if method in ("on_open", "open", "flag"):
        return mark_refresh_on_open(path, out)
    if method != "auto":
        raise XlcopyError("method must be 'auto', 'excel' or 'on_open', not %r" % method)
    if excel_available():
        try:
            return "refreshed in Excel: %s" % refresh_with_excel(path, out, timeout)
        except XlcopyError as err:
            if "not available" not in str(err) and "cscript was not found" not in str(err):
                raise
    return mark_refresh_on_open(path, out)
