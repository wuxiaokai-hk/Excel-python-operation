"""xlcopy - copy and filter Excel data with only the Python standard library.

No pip install: put the `xlcopy` folder next to your script (or add its parent
folder to sys.path) and `import xlcopy`.

Quick start
-----------
    import xlcopy

    t = xlcopy.read_table("source.xlsx", sheet="Data")      # row 1 = headers
    t = t.select("Date", "GDP", "CPI").between("Date", "2020-01-01", None)
    xlcopy.write_table("template.xlsx", t, sheet="Input", start="A1",
                       out="filled.xlsx")
"""

from .workbook import Workbook, Formula, XlcopyError, backup
from .table import Table
from ._cells import col_to_index, index_to_col, parse_cell, make_ref
from .refresh import refresh, refresh_with_excel, mark_refresh_on_open
from .compare import compare, summary_text
from .checks import run_checks
from .table import text_to_number

__version__ = "1.0.0"

__all__ = ["Workbook", "Table", "Formula", "XlcopyError", "read_table", "read_rows",
           "write_table", "copy", "sheet_names", "col_to_index", "index_to_col",
           "parse_cell", "make_ref", "backup", "run_jobs",
           "refresh", "refresh_with_excel", "mark_refresh_on_open",
           "compare", "summary_text", "run_checks", "text_to_number"]


def sheet_names(path):
    """List the sheet names of a workbook."""
    return Workbook.open(path).sheet_names


def read_rows(path, sheet=None, range=None, dates=True):
    """All values of a sheet (or a range like 'A1:F100') as a list of lists."""
    return Workbook.open(path).read_rows(sheet, range, dates)


def read_table(path, sheet=None, header_row=1, range=None, dates=True):
    """Read a sheet into a Table. `sheet` is a name or 0-based index (default: first sheet)."""
    return Workbook.open(path).read_table(sheet, header_row=header_row, range=range, dates=dates)


def write_table(path, table, sheet=None, start="A1", header=True, out=None,
                by_header=False, header_row=1, key=None, clear=None, create_sheet=False):
    """Write a Table into an existing workbook (or a new one if `path` doesn't exist).

    by_header=False : paste the block at `start` (header row first if header=True).
    by_header=True  : put each column under the matching header in row `header_row`
                      of the target sheet; `key` (e.g. 'Date') lines rows up.
    clear           : range to empty first, e.g. 'A2:Z5000' (formatting is kept).
    out             : save to this file instead of overwriting `path`.
    Returns a report dict when by_header=True, else the number of rows written.
    """
    import os
    if os.path.exists(path):
        wb = Workbook.open(path)
    else:
        wb = Workbook.new([sheet if isinstance(sheet, str) else "Sheet1"])
    if isinstance(sheet, str) and sheet.casefold() not in [n.casefold() for n in wb.sheet_names]:
        if create_sheet:
            wb.add_sheet(sheet)
        else:
            raise XlcopyError("No sheet named %r in %s (sheets: %s). Pass create_sheet=True to add it."
                              % (sheet, path, wb.sheet_names))
    if clear:
        wb.clear(sheet, clear)
    if by_header:
        result = wb.write_by_header(sheet, table, header_row=header_row, key=key)
    else:
        result = wb.write_table(sheet, table, start=start, header=header)
    wb.save(out or path)
    return result


def copy(src, dst, columns=None, src_sheet=None, dst_sheet=None, start="A1", header=True,
         header_row=1, where=None, out=None, by_header=False, key=None, clear=None):
    """One-liner: read `columns` from src, optionally filter, write into dst.

    where: dict like {"Region": ["ON", "BC"]} - keep rows whose value is in the list.
    """
    t = read_table(src, sheet=src_sheet, header_row=header_row)
    if columns:
        t = t.select(list(columns))
    for col, val in (where or {}).items():
        t = t.where(col, val)
    return write_table(dst, t, sheet=dst_sheet, start=start, header=header, out=out,
                       by_header=by_header, key=key, clear=clear)


def run_jobs(config_path, dry_run=False):
    """Run the copy jobs described in a JSON file (see README)."""
    from .jobs import run_file
    return run_file(config_path, dry_run=dry_run)
