"""Cell-reference and date helpers (standard library only)."""

import datetime
import re

_CELL_RE = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d+)$")
_COL_RE = re.compile(r"^\$?([A-Za-z]{1,3})$")
_ROW_RE = re.compile(r"^\$?(\d+)$")

MAX_ROW = 1048576
MAX_COL = 16384

EPOCH_1900 = datetime.datetime(1899, 12, 30)
EPOCH_1904 = datetime.datetime(1904, 1, 1)


def col_to_index(letters):
    """'A' -> 1, 'Z' -> 26, 'AA' -> 27."""
    n = 0
    for ch in letters.upper():
        n = n * 26 + (ord(ch) - 64)
    return n


def index_to_col(n):
    """1 -> 'A', 27 -> 'AA'."""
    if n < 1:
        raise ValueError("column index must be >= 1")
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def parse_cell(ref):
    """'B3' -> (3, 2)  (row, col), both 1-based."""
    m = _CELL_RE.match(ref.strip())
    if not m:
        raise ValueError("Not a cell reference: %r (expected something like 'B3')" % ref)
    return int(m.group(2)), col_to_index(m.group(1))


def make_ref(row, col):
    """(3, 2) -> 'B3'."""
    return "%s%d" % (index_to_col(col), row)


def parse_range(ref):
    """Parse 'A1:C10', 'B2', 'A:C' or '2:10'.

    Returns (row1, col1, row2, col2). row2/col2 may be None meaning
    "to the end of the data".
    """
    ref = ref.strip()
    if ":" not in ref:
        r, c = parse_cell(ref)
        return r, c, r, c
    a, b = [p.strip() for p in ref.split(":", 1)]
    if _CELL_RE.match(a) and _CELL_RE.match(b):
        r1, c1 = parse_cell(a)
        r2, c2 = parse_cell(b)
    elif _COL_RE.match(a) and _COL_RE.match(b):
        r1, c1 = 1, col_to_index(_COL_RE.match(a).group(1))
        r2, c2 = None, col_to_index(_COL_RE.match(b).group(1))
    elif _ROW_RE.match(a) and _ROW_RE.match(b):
        r1, c1 = int(a.lstrip("$")), 1
        r2, c2 = int(b.lstrip("$")), None
    else:
        raise ValueError("Not a range: %r (expected e.g. 'A1:C10', 'A:C' or '2:10')" % ref)
    if r2 is not None and r2 < r1:
        r1, r2 = r2, r1
    if c2 is not None and c2 < c1:
        c1, c2 = c2, c1
    return r1, c1, r2, c2


def to_serial(value, date1904=False):
    """datetime/date/time -> Excel serial number."""
    if isinstance(value, datetime.time):
        return (value.hour * 3600 + value.minute * 60 + value.second
                + value.microsecond / 1e6) / 86400.0
    if not isinstance(value, datetime.datetime):
        value = datetime.datetime(value.year, value.month, value.day)
    if value.tzinfo is not None:
        value = value.replace(tzinfo=None)
    delta = value - (EPOCH_1904 if date1904 else EPOCH_1900)
    serial = delta.days + delta.seconds / 86400.0 + delta.microseconds / 86400e6
    if serial == int(serial):
        return int(serial)
    return serial


def from_serial(x, date1904=False):
    """Excel serial number -> datetime (rounded to the millisecond)."""
    base = EPOCH_1904 if date1904 else EPOCH_1900
    ms = int(round(x * 86400000))
    return base + datetime.timedelta(milliseconds=ms)


_DATE_STR_RE = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$")


def parse_date_string(s):
    """'2025-01-31' or '2025-01-31 10:30' -> datetime, else None."""
    m = _DATE_STR_RE.match(s.strip())
    if not m:
        return None
    parts = [int(p) if p else 0 for p in m.groups()]
    try:
        return datetime.datetime(*parts)
    except ValueError:
        return None


def norm(x):
    """Normalise a value for matching headers/keys.

    Strings are stripped and case-folded; numbers 2025 and 2025.0 and the
    string '2025' all match; a date matches its ISO text ('2025-01-31').
    """
    if x is None:
        return None
    if isinstance(x, bool):
        return str(x).casefold()
    if isinstance(x, datetime.datetime):
        if x.hour == x.minute == x.second == x.microsecond == 0:
            return x.date().isoformat()
        return x.isoformat(sep=" ")
    if isinstance(x, datetime.date):
        return x.isoformat()
    if isinstance(x, (int, float)):
        f = float(x)
        if f.is_integer():
            return str(int(f))
        return repr(f)
    s = str(x).strip()
    d = parse_date_string(s)
    if d is not None:
        return norm(d)
    try:
        f = float(s.replace(",", ""))
        if s.replace(",", "").replace(".", "", 1).lstrip("-+").isdigit():
            return norm(f)
    except ValueError:
        pass
    return s.casefold()
