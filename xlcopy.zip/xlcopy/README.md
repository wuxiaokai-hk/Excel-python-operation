# xlcopy

Filter variables and copy values from one Excel workbook to another, using **only the Python standard library**. No `pip install`, no openpyxl, pandas or xlwings.

Works with `.xlsx` and `.xlsm` files and Python 3.7 or newer. It does not handle old `.xls` or `.xlsb` files; save those as `.xlsx` first.

## Install

There's nothing to install. Copy the `xlcopy` folder (the one that contains `__init__.py`) next to your script:

```
my_work/
├── xlcopy/            <- this folder
├── fill_template.py   <- your script
└── jobs.json
```

If you keep `xlcopy` somewhere else, add this at the top of your script:

```python
import sys; sys.path.insert(0, r"C:\path\to\folder\that\contains\xlcopy")
```

## What it keeps in the target file

xlcopy changes only the cell values you write. It keeps everything else in the target workbook:

- cell formatting, number formats, column widths and merged cells
- other sheets, formulas, named ranges, charts, pivot tables and macros (`.xlsm`)

Formulas that depend on the pasted cells recalculate when the file is next opened in Excel. A date written into a cell that has no date format gets a date format; any other formatting on that cell stays.

**Close the target file in Excel before you run a copy.** On Windows the save fails while the file is open, and xlcopy tells you so.

## 1. Python usage

```python
import xlcopy

# Read: row 1 holds the headers. sheet= takes a name or a 0-based index.
t = xlcopy.read_table("scenario_export.xlsx", sheet="Data")
t.show()                                   # prints the first 10 rows

# Filter. Each step returns a new table, so steps can be chained.
t = (t.where("Scenario", "Baseline")                 # one value or a list
      .between("Date", "2020-01-01", "2030-12-31")   # dates or numbers
      .select("Date", "GDP", "CPI", "Unemployment")  # keep these columns, in this order
      .rename({"Unemployment": "UR"}))

# Write option A: paste the block at a cell
xlcopy.write_table("template.xlsx", t, sheet="Input", start="A1",
                   clear="A2:Z5000",            # optional: empty the old data first
                   out="template_filled.xlsx")  # omit out= to overwrite template.xlsx

# Write option B: put each column under the matching header in the target
xlcopy.write_table("template.xlsx", t, sheet="Input", by_header=True,
                   header_row=1, key="Date", out="template_filled.xlsx")
```

With `by_header=True`, each source column goes under the target column that has the same header. Header matching ignores case and extra spaces. Target columns that aren't in your table, such as formula columns, are left alone. With `key="Date"`, rows are matched on date, and any dates not yet in the target are added at the bottom.

### Lower-level control

```python
from xlcopy import Workbook, Formula

wb = Workbook.open("template.xlsx")
print(wb.sheet_names)
print(wb.get("Input", "B3"))                 # one cell
rows = wb.read_rows("Input", "A1:F50")       # list of lists
wb.set("Input", "B3", 1.25)                  # one cell (formatting kept)
wb.set("Input", "H1", Formula("SUM(B2:B50)"))
wb.write_rows("Input", "C10", [[1, 2], [3, 4]])
wb.clear("Input", "A100:Z200")
wb.add_sheet("Raw copy")
wb.save("template_filled.xlsx")              # wb.save() overwrites the original

new = Workbook.new(["Summary"])              # create a workbook from scratch
new.write_table("Summary", t, start="A1")
new.save("summary.xlsx")
```

### Table methods

| method | what it does |
|---|---|
| `select("A", "B", rename={...})` | keep these columns, in this order |
| `select_if(lambda h: ...)` | keep columns whose header passes a test |
| `drop("Note")` | remove columns |
| `where("Region", ["ON", "BC"])` | keep rows whose value is in the list (also takes one value or a function) |
| `where_not("Region", "QC")` | remove matching rows |
| `between("Date", "2020-01-01", None)` | keep rows in a range; either end can be `None` |
| `filter(lambda r: r["GDP"] > 0)` | any condition on the row (given as a dict) |
| `transpose()` | swap rows and columns, for when variables are rows and dates run across |
| `map_column("GDP", lambda v: v / 1000)` | change a column's values |
| `rename({...})`, `head(n)`, `show(n)`, `column(name)`, `to_rows()`, `to_dicts()` | other helpers |

**Wide data (variables in rows, dates across).** Choose the variables with `where` on the name column:

```python
t = xlcopy.read_table("moodys.xlsx", sheet="Data")    # header row = Mnemonic, 2024-01-01, 2024-04-01 ...
t = t.where("Mnemonic", ["FGDP$.ON", "FCPIU.ON"])     # keep these variables (rows)
t = t.select_if(lambda h: h == "Mnemonic" or str(h) >= "2025")   # choose date columns
t_long = t.transpose()                                 # optional: dates down, variables across
```

### Refresh a workbook (recalculate, Refresh All)

```python
xlcopy.refresh("report.xlsx")                       # auto: Excel if possible, else flag the file
xlcopy.refresh("report.xlsx", method="excel")       # now, in a hidden Excel (Windows)
xlcopy.refresh("report.xlsx", method="on_open")     # Excel refreshes when the file is next opened
xlcopy.refresh("report.xlsx", out="report_refreshed.xlsx")
```

- **`excel`** opens the file in a hidden copy of the Excel installed on your PC, through a small VBScript that `cscript` runs. `cscript` is part of Windows, so nothing has to be installed. It runs **Data › Refresh All** (Power Query, data connections, pivot tables), waits for the queries to finish, recalculates every formula, then saves and closes. Afterwards `read_table`/`read_rows` return the new values. The file must not be open in Excel at the same time.
- **`on_open`** works on any computer and doesn't need Excel. It sets flags in the file so that formulas recalculate and pivot tables and data connections refresh the next time someone opens it. Until then, xlcopy still reads the old saved values.
- **`auto`** (the default) uses `excel` and falls back to `on_open` if Excel can't be reached.

Typical use: write the inputs, refresh, then read the model's outputs.

```python
xlcopy.write_table("model.xlsx", inputs, sheet="Input", by_header=True, key="Date")
xlcopy.refresh("model.xlsx", method="excel")
results = xlcopy.read_table("model.xlsx", sheet="Output")
```

Command line: `python -m xlcopy refresh model.xlsx --method excel`. In a JSON job, add `"refresh": "excel"` (or `"on_open"`, or `true` for auto) to refresh the output file after it's saved.

If your company blocks scripts (VBScript or `cscript`), the `excel` method fails with a clear error. `on_open` still works in that case.

### Compare the original and the changed file

```python
changes = xlcopy.compare("model_before.xlsx", "model_after.xlsx", report="changes.xlsx")
print(xlcopy.summary_text(changes))
```

This checks every cell on every sheet and lists what was **changed**, **added** or **deleted**. It also flags formula changes: a formula replaced by a value, a formula added, or a formula's text edited. Each line shows the sheet, the cell, and for context the row label (column A) and column header (row 1), followed by the old value, the new value, and for numbers the difference and the % change. The report file has a **Summary** sheet with counts and a **Changes** sheet with one line per changed cell.

Options:

- `sheets=["Input"]` limits the comparison to some sheets.
- `tolerance=1e-6` ignores tiny numeric differences.
- `header_row=` and `label_col=` take the context from somewhere else (default row 1 and column A).
- `ignore_formula_values=True` compares only the formula text, which is useful if the new file hasn't been recalculated yet.

To compare formula **results** too, run `refresh(..., method="excel")` on the changed file first. Command line:

```
python -m xlcopy compare model_before.xlsx model_after.xlsx --report changes.xlsx
```

In a JSON job, `"compare": true` keeps the target as it was before the job, compares it with the saved output, and writes `<output>_changes_<date_time>.xlsx` next to it. `"compare": "reports/changes.xlsx"` chooses the path.

### Clean numbers and check data before writing

Use `to_numbers` to turn numbers stored as text into real numbers. It converts `"1,234.5"`, `"(5.2)"` (negative), `"$1,000"` and `"3.1%"` (to 0.031) and leaves other text alone.

```python
t = t.to_numbers("GDP", "CPI")      # or t.to_numbers() for every column
```

`run_checks` returns a list of problems; an empty list means everything passed.

```python
problems = xlcopy.run_checks(t, {
    "required_columns": ["Date", "GDP", "CPI"],
    "min_rows": 12, "max_rows": 500,
    "no_blanks": ["Date"],                 # no empty cells
    "numeric": ["GDP", "CPI"],             # every non-empty cell is a number
    "unique": ["Date"],                    # no repeated dates
    "ranges": {"CPI": [0, 0.2]},           # allowed min/max (use null for no limit)
    "max_change_pct": {"GDP": 15}          # biggest allowed jump between rows
})
```

In a JSON job, put the same dictionary under `"checks"` and add `"to_numbers": true` or a list of columns. If any check fails, the job stops and **nothing is written**. In a job, `required_columns` uses the column names as they appear in the source file, before `columns` and `rename` are applied; the other checks see the final columns.

## 2. Repeat a job with one command (JSON)

Put the steps in a JSON file once, then run it every time new data arrives. Paths are relative to the JSON file. `examples/jobs_example.json` is a ready-to-edit sample.

```json
{
  "jobs": [
    {
      "name": "Baseline macro inputs",
      "source": "data/scenario_export.xlsx",
      "source_sheet": "Data",
      "header_row": 1,
      "where": {"Scenario": "Baseline"},
      "between": {"Date": ["2020-01-01", "2030-12-31"]},
      "columns": ["Date", "GDP", "CPI", "Unemployment"],
      "rename": {"Unemployment": "UR"},
      "target": "model/template.xlsx",
      "target_sheet": "Input",
      "mode": "match_headers",
      "key": "Date",
      "output": "model/template_filled.xlsx"
    }
  ]
}
```

```
python -m xlcopy run jobs.json --dry-run     # show what would be copied; writes nothing
python -m xlcopy run jobs.json
```

| setting | meaning |
|---|---|
| `source`, `source_sheet`, `header_row`, `source_range` | where to read from (`source_range` example: `"B3:K400"`) |
| `transpose` | `true` to swap rows and columns after reading |
| `where`, `where_not`, `between` | row filters, applied before `columns` |
| `columns`, `rename` | which variables to keep, and new names for them |
| `target`, `target_sheet`, `create_sheet` | where to write; `create_sheet: true` adds the sheet if it's missing |
| `mode` | `"paste"` (needs `start` and `write_header`) or `"match_headers"` (uses `target_header_row` and optional `key`) |
| `clear` | range to empty before writing, e.g. `"A2:Z5000"` |
| `output` | file to save to; defaults to overwriting `target` |
| `backup` | `true` to keep a `.bak` copy of the output file's previous version |
| `refresh` | `"excel"`, `"on_open"` or `true` (auto): refresh the output file after saving |
| `to_numbers` | `true` (all columns) or a list of columns: convert numbers stored as text |
| `checks` | validation rules (see above); if any fails, nothing is written |
| `compare` | `true` or a report path: write a report of what changed in the output |

When several jobs write to the same `output`, they all go into one file, which is saved once at the end.

## 3. Command line

The `python -m xlcopy` commands work from the folder that contains `xlcopy`.

```
python -m xlcopy sheets  file.xlsx
python -m xlcopy headers file.xlsx --sheet Data
python -m xlcopy preview file.xlsx --sheet Data -n 15 --columns "Date,GDP"
python -m xlcopy copy --src export.xlsx --src-sheet Data --columns "Date,GDP,CPI" ^
       --where "Region=ON,BC" --dst template.xlsx --dst-sheet Input --start A1 --out filled.xlsx
python -m xlcopy copy ... --by-header --key Date        # write under matching headers instead of pasting at a cell
python -m xlcopy refresh model.xlsx --method excel      # Refresh All + recalculate
python -m xlcopy compare old.xlsx new.xlsx --report changes.xlsx
```

(`^` continues a line in Windows cmd; use `\` on Mac or Linux.)

## Notes and limits

- Formulas in the source are read as their last calculated values, i.e. what Excel showed when the file was last saved.
- Dates come back as Python `datetime` when the cell has a date format; otherwise they're plain numbers.
- Strings that look like dates, such as `"2025-01-31"`, match date cells in `where`, `between`, headers and keys.
- Overwriting the first cell of a block of shared formulas (one formula filled down) turns the rest of that block into values. You get a warning when this happens. Overwriting the cells those formulas *read from* is fine.
- Charts and pivot tables keep their references; pivot tables refresh when you refresh them in Excel.
- Run the self-tests from this folder with `python -m unittest discover tests`.
